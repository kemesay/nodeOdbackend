const { sequelize } = require("../config/database"); // Adjust path as needed
const { Op } = require("sequelize");
const { PaymentDetail } = require("../models/PaymentDetail.js");
const { ValidationError, ResourceNotFoundError } = require("../errors/CustomErrors.js");
const {
  createSquareCustomer,
  createCardOnFile,
  getCustomerIdForCard,
} = require("./payments/squarePaymentService.js");
const { isSquarePaymentProvider } = require("../config/paymentConfig.js");
const logger = require("../config/logging.js");

async function addOrUpdatePaymentDetail(
  creditCardNumber,
  expirationDate,
  securityCode,
  zipCode,
  cardOwnerName,
  ...otherData
) {
  // Find a payment detail with the given credit card details
  const existingPaymentDetail = await PaymentDetail.findOne({
    where: {
      creditCardNumber,
      expirationDate,
      securityCode,
      zipCode,
      cardOwnerName,
    },
  });

  if (existingPaymentDetail) {
    // If found, update the existing record
    await existingPaymentDetail.update({
      creditCardNumber,
      expirationDate,
      securityCode,
      zipCode,
      cardOwnerName,
      isPrimary: false,
    });

    return existingPaymentDetail;
  } else {
    // If not found, create a new payment detail
    const newPaymentDetail = await PaymentDetail.create({
      creditCardNumber,
      expirationDate,
      securityCode,
      zipCode,
      cardOwnerName,
      isPrimary: false,
    });

    return newPaymentDetail;
  }

}

async function getPaymentDetail(creditCardNumber, expirationDate, securityCode, zipCode, cardOwnerName) {
  const paymentDetail = await PaymentDetail.findOne({
    where: {
      creditCardNumber,
      expirationDate,
      securityCode,
      zipCode,
      cardOwnerName,
    },
  });
  return paymentDetail;
}

async function findExistingCard(cardDetails) {
  return await PaymentDetail.findOne({
    where: {
      creditCardNumber: cardDetails.creditCardNumber,
      expirationDate: cardDetails.expirationDate,
      securityCode: cardDetails.securityCode,
      zipCode: cardDetails.zipCode,
      cardOwnerName: cardDetails.cardOwnerName,
      userId: cardDetails.userId || null
    }
  });
}


async function handlePrimaryCardUpdate(userId, newPrimaryId = null) {
  if (!userId) return;
  
  // Find current primary card
  const currentPrimary = await PaymentDetail.findOne({
    where: {
      userId,
      isPrimary: true
    }
  });

  // If there's a current primary card and it's not the new one being set
  if (currentPrimary && (!newPrimaryId || currentPrimary.paymentDetailId !== newPrimaryId)) {
    await currentPrimary.update({ isPrimary: false });
  }
}

// async function createPaymentDetail(cardDetails) {
//   try {
//     // If this is marked as primary, unset any existing primary cards for this user
//     if (cardDetails.isPrimary && cardDetails.userId) {
//       await PaymentDetail.update(
//         { isPrimary: false },
//         {
//           where: {
//             userId: cardDetails.userId,
//             isPrimary: true
//           }
//         }
//       );
//     }

//     const paymentDetail = await PaymentDetail.create({
//       creditCardNumber: cardDetails.creditCardNumber,
//       expirationDate: cardDetails.expirationDate,
//       securityCode: cardDetails.securityCode,
//       zipCode: cardDetails.zipCode,
//       cardOwnerName: cardDetails.cardOwnerName,
//       userId: cardDetails.userId || null,
//       isPrimary: cardDetails.isPrimary || false
//     });

//     return paymentDetail;
//   } catch (error) {
//     throw new Error(`Failed to create payment detail: ${error.message}`);
//   }
// }

async function createPaymentDetail(cardDetails) {
  // Check if identical card already exists
  const existingCard = await findExistingCard(cardDetails);
  if (existingCard) {
    // Update existing card instead of creating new one
    return await updatePaymentDetail(existingCard.paymentDetailId, cardDetails);
  }

  // Handle primary card logic
  if (cardDetails.isPrimary && cardDetails.userId) {
    await handlePrimaryCardUpdate(cardDetails.userId);
  }

  const paymentDetail = await PaymentDetail.create({
    creditCardNumber: cardDetails.creditCardNumber,
    expirationDate: cardDetails.expirationDate,
    securityCode: cardDetails.securityCode,
    zipCode: cardDetails.zipCode,
    cardOwnerName: cardDetails.cardOwnerName,
    userId: cardDetails.userId || null,
    isPrimary: cardDetails.isPrimary || false
  });

  return paymentDetail;
}

// async function updatePaymentDetail(paymentDetailId, paymentDetailData) {
//   const paymentDetail = await getPaymentDetailById(paymentDetailId);
//   if (!paymentDetail) {
//     throw new Error("Payment detail  with id ${paymentDetailId} not found");
//   }
//    return  await paymentDetail.update(paymentDetailData);
// }

async function updatePaymentDetail(paymentDetailId, paymentDetailData) {
  const paymentDetail = await getPaymentDetailById(paymentDetailId);
  if (!paymentDetail) {
    throw new ResourceNotFoundError(`Payment detail with id ${paymentDetailId} not found`);
  }

  // Check if identical card already exists elsewhere
  const existingCard = await findExistingCard(paymentDetailData);
  if (existingCard && existingCard.paymentDetailId !== paymentDetailId) {
    throw new ValidationError("This card already exists in the system");
  }

  // Handle primary card logic
  if (paymentDetailData.isPrimary && paymentDetail.userId) {
    await handlePrimaryCardUpdate(paymentDetail.userId, paymentDetailId);
  }

  return await paymentDetail.update(paymentDetailData);
}
async function getPaymentDetails({
  page = 1,
  pageSize = 10,
  sortDirection = "DESC",
}) {
  const paymentDetails = await PaymentDetail.findAll({
    order: [["createdAt", sortDirection]],
    offset: (page - 1) * pageSize,
    limit: pageSize,
  });
  return paymentDetails;
}

async function getPaymentDetailById(paymentDetailId) {
  const paymentDetail = await PaymentDetail.findByPk(paymentDetailId);
  if (!paymentDetail) {
    throw new Error(`Payment detail with id ${paymentDetailId} not found`);
  }
  return paymentDetail;
}

async function deletePaymentDetail(paymentDetailId) {
  const paymentDetail = await PaymentDetail.getPaymentDetailById(paymentDetailId);
  if (!paymentDetail) {
    throw new Error("Payment detail not found");
  }
  await paymentDetail.destroy();
}
async function getPrimaryCard(userId) {
  if (!userId) {
    throw new ValidationError("User ID is required to fetch primary card");
  }

  const primaryCard = await PaymentDetail.findOne({
    where: {
      userId: userId,
      isPrimary: true
    }
  });

  if (!primaryCard) {
    throw new ValidationError("No primary card found for this user");
  }

  return primaryCard;
}

/**
 * Whether this user already has at least one card actually linked to
 * Square (saved via the Square SDK, not a legacy raw-PAN row). Used to
 * steer a failed "add new card" attempt toward an existing saved/primary
 * card instead of telling the customer to keep re-entering card details.
 */
async function hasUsableSavedSquareCard(userId) {
  if (!userId) return false;
  const existing = await PaymentDetail.findOne({
    where: { userId, squareCardId: { [Op.ne]: null } },
  });
  return Boolean(existing);
}
async function getFromExistingCards(paymentDetailId, userId) {
  if (!paymentDetailId || !userId) {
    throw new ValidationError("Payment detail ID and user ID are required");
  }

  const card = await PaymentDetail.findOne({
    where: {
      paymentDetailId: paymentDetailId,
      userId: userId
    }
  });

  if (!card) {
    throw new ValidationError("Card not found or unauthorized access");
  }

  return card;
}

/**
 * Square requires customer_id when charging a card on file (ccof:...).
 */
async function resolveSquareCustomerId({ userId, paymentDetail, squareCardId }) {
  if (paymentDetail?.squareCustomerId) {
    return paymentDetail.squareCustomerId;
  }

  // Resolve authoritatively from Square, by the card's OWN id, whenever one
  // is available — never guess from another of this user's PaymentDetail
  // rows. A user can end up with cards saved under more than one Square
  // customer record (e.g. a card added as "primary" and a different card
  // added separately as a "saved card"); pairing the wrong guessed
  // customer_id with THIS card's source_id sends Square a source_id/
  // customer_id pair that don't actually belong together, which Square
  // rejects as INVALID_CARD_DATA — this previously-used "most recently
  // updated sibling" guess was exactly that bug, and it also permanently
  // wrote the wrong guess back onto the card's own row, making the mistake
  // stick on every future charge of that card.
  const onFileId = squareCardId || paymentDetail?.squareCardId;
  if (onFileId && String(onFileId).startsWith("ccof:")) {
    try {
      const customerId = await getCustomerIdForCard(onFileId);
      if (paymentDetail?.paymentDetailId) {
        await paymentDetail.update({ squareCustomerId: customerId }).catch(() => {});
      }
      return customerId;
    } catch (err) {
      // Square itself doesn't recognize this card id any more (removed,
      // expired, or never valid). Don't let it keep silently failing as
      // someone's "primary" card — unset that flag so it stops being
      // auto-selected, and surface a clear message instead of retrying
      // with a guessed customer id.
      if (paymentDetail?.paymentDetailId && paymentDetail.isPrimary) {
        await paymentDetail.update({ isPrimary: false }).catch(() => {});
        logger.warn(
          `[paymentDetailService] Cleared isPrimary on PaymentDetail ${paymentDetail.paymentDetailId} — Square no longer recognizes card ${onFileId}: ${err.message}`
        );
      }
      throw new ValidationError(
        "This saved card is no longer valid with Square. Please remove it and add it again, or choose a different payment method."
      );
    }
  }

  if (userId) {
    const sibling = await PaymentDetail.findOne({
      where: { userId, squareCustomerId: { [Op.ne]: null } },
      order: [["updatedAt", "DESC"]],
    });
    if (sibling?.squareCustomerId) {
      return sibling.squareCustomerId;
    }
  }

  throw new ValidationError(
    "Saved card is missing Square customer linkage. Re-add the card in Payment Methods."
  );
}

/**
 * Save a card using Square Web/Mobile SDK nonce (no PAN stored).
 */
async function saveSquareCardOnFile(userId, data) {
  if (!isSquarePaymentProvider()) {
    throw new ValidationError("Square payments are not enabled");
  }

  const { sourceId, cardOwnerName, zipCode, isPrimary, email } = data;
  if (!sourceId || !cardOwnerName || !zipCode) {
    throw new ValidationError("sourceId, cardOwnerName, and zipCode are required");
  }

  let squareCustomerId = null;
  const existingWithCustomer = await PaymentDetail.findOne({
    where: { userId, squareCustomerId: { [Op.ne]: null } },
  });
  if (existingWithCustomer?.squareCustomerId) {
    squareCustomerId = existingWithCustomer.squareCustomerId;
  } else {
    const nameParts = String(cardOwnerName).trim().split(/\s+/);
    squareCustomerId = await createSquareCustomer({
      emailAddress: email || `user${userId}@guest.odatransportation.local`,
      givenName: nameParts[0] || "Cardholder",
      familyName: nameParts.slice(1).join(" ") || "User",
      referenceId: userId,
    });
  }

  const card = await createCardOnFile({
    customerId: squareCustomerId,
    sourceId,
    cardholderName: cardOwnerName,
    postalCode: zipCode,
    referenceId: userId,
  });

  if (isPrimary) {
    await handlePrimaryCardUpdate(userId);
  }

  const paymentDetail = await PaymentDetail.create({
    userId,
    squareCustomerId,
    squareCardId: card.squareCardId,
    cardBrand: card.cardBrand,
    last4: card.last4,
    expMonth: card.expMonth,
    expYear: card.expYear,
    cardOwnerName,
    zipCode,
    isPrimary: Boolean(isPrimary),
    creditCardNumber: null,
    expirationDate: null,
    securityCode: null,
  });

  return paymentDetail;
}

async function setPrimaryCard(paymentDetailId, userId) {
  const transaction = await sequelize.transaction();
  try {
    // 1. Get the card to be set as primary
    const cardToSetPrimary = await PaymentDetail.findOne({
      where: { paymentDetailId, userId },
      transaction
    });

    if (!cardToSetPrimary) {
      throw new ResourceNotFoundError("Card not found or unauthorized access");
    }

    // 2. Find current primary card (if any)
    const currentPrimaryCard = await PaymentDetail.findOne({
      where: { userId, isPrimary: true, paymentDetailId: { [Op.ne]: paymentDetailId } },
      transaction
    });

    // 3. Unset current primary if exists
    if (currentPrimaryCard) {
      await currentPrimaryCard.update({ isPrimary: false }, { transaction });
    }

    // 4. Set new primary card
    await cardToSetPrimary.update({ isPrimary: true }, { transaction });

    // Commit transaction
    await transaction.commit();

    return cardToSetPrimary;
  } catch (error) {
    await transaction.rollback();
    throw error;
  }
}

module.exports = {
  addOrUpdatePaymentDetail,
  getPaymentDetail,
  createPaymentDetail,
  updatePaymentDetail,
  getPaymentDetails,
  getPaymentDetailById,
  deletePaymentDetail,
  getPrimaryCard,
  getFromExistingCards,
  setPrimaryCard,
  saveSquareCardOnFile,
  resolveSquareCustomerId,
  hasUsableSavedSquareCard,
};
