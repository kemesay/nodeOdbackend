// const { HourlyCharterBook } = require("../models/HourlyCharterBook.js");
// const { PointToPointBook } = require("../models/PointToPointBook.js");
// const { AirportBook } = require("../models/airportBooking/AirportBook.js");
// const { PaymentDetail } = require("../models/PaymentDetail.js");
// const { Car } = require("../models/Car.js");
// const { Op } = require("sequelize");
// const { Gratuity } = require("../models/Gratuity.js");
// const { AdditionalStopOnTheWay } = require("../models/booking/AdditionalStopOnTheWay.js");
// const { AirportPickupPreference } = require("../models/airportBooking/AirportPickupPreference.js");
// const { ExtraOption } = require("../models/ExtraOption.js");

// // Define a function to search user bookings by user ID
// async function searchUserBookingsByUserId(userId) {
//   // Define options for querying
//   const queryOptions = {
//     where: {
//       userId: userId,
//       deletedAt: { [Op.is]: null }, // Filter out soft-deleted records
//     },
//     order: [["updatedAt", "DESC"]],
//     attributes: { exclude: ["deletedAt"] },
//     include: [
//       {
//         model: Car, // Include the Car model
//         attributes: ["carImageUrl"],
//       },
//     ],
//   };

//   // Search point-to-point bookings
//   const pointToPointBookings = await PointToPointBook.findAll(queryOptions);

//   // Search hourly charter bookings
//   const hourlyCharterBookings = await HourlyCharterBook.findAll(queryOptions);

//   // Search airport bookings
//   const airportBookings = await AirportBook.findAll(queryOptions);

//   return {
//     pointToPointBookings,
//     hourlyCharterBookings,
//     airportBookings,
//   };
// }

// async function getPaymentDetailByUserId(userId) {
//  const queryOptions = {
//   where: {
//     userId: userId,
//     // deletedAt: { [Op.is]: null },
//   },
//   order: [["updatedAt"]],
//   // attributes: { exclude: ["deletedAt"] },
//  };
 
//  const paymentDetail = await PaymentDetail.findAll(queryOptions);
 
//  return paymentDetail;
 
 
 
// }

// async function calculateP2PTotalTripPrice(booking) {
//   const { pricePerMile, minimumStartFee } = booking.Car;
//   const percentage = booking.Gratuity.percentage;

//   let carPrice =
//     Number(pricePerMile * booking.distanceInMiles) + Number(minimumStartFee);
  
//   if (booking.tripType === "Round-Trip") carPrice *= 2;

//   let additionalStopPrice = booking.AdditionalStopOnTheWay
//     ? booking.AdditionalStopOnTheWay.additionalStopPrice
//     : 0;

//   let extraOptionsPrice = 0;
//   if (booking.ExtraOptions) {
//     if (booking.tripType === "Round-Trip") {

//         for (const extraOption of Object.values(booking.ExtraOptions)) {
//           extraOptionsPrice +=
//             extraOption.pricePerItem *
//             extraOption.PointToPointBookExtraOption.quantity;
//         }
//         extraOptionsPrice *= 2;

//       } else {
//         for (const extraOption of Object.values(booking.ExtraOptions)) {
//           extraOptionsPrice +=
//             extraOption.pricePerItem *
//             extraOption.PointToPointBookExtraOption.quantity;
//         }
//       }

    
//   }

//   const tripPrice =
//     Number(carPrice) + Number(additionalStopPrice) + Number(extraOptionsPrice);

//   const totalPrice = tripPrice + tripPrice * (percentage / 100);
//   return Number(totalPrice.toFixed(2));
// }

// async function calculateHourlyCharterTotalTripPrice(booking) {
//   const { pricePerHour, minimumStartFee } = booking.Car;
//   const percentage = booking.Gratuity.percentage;

//   let carPrice = pricePerHour * booking.selectedHours;

//   let extraOptionsPrice = 0;
//   if (booking.ExtraOptions) {
//     for (const extraOption of Object.values(booking.ExtraOptions)) {
//       extraOptionsPrice +=
//         extraOption.pricePerItem *
//         extraOption.HourlyCharterBookExtraOption.quantity;
//     }
//   }

//   const tripPrice = Number(carPrice) + Number(extraOptionsPrice);
//   const totalPrice = tripPrice + tripPrice * (percentage / 100);
//   return Number(totalPrice.toFixed(2));
// }

// async function calculateAirportBookingTotalTripPrice(booking) {
//   // First, ensure we have all necessary associations loaded
//   if (!booking.Car || !booking.Gratuity) {
//     // Reload the booking with all necessary associations
//     booking = await AirportBook.findByPk(booking.airportBookId, {
//       include: [
//         {
//           model: Car,
//           attributes: ['pricePerMile', 'minimumStartFee'],
//         },
//         {
//           model: Gratuity,
//           attributes: ['percentage'],
//         },
//         {
//           model: AdditionalStopOnTheWay,
//           attributes: ['additionalStopPrice'],
//         },
//         {
//           model: AirportPickupPreference,
//           attributes: ['preferencePrice'],
//         },
//         {
//           model: ExtraOption,
//           through: {
//             attributes: ['quantity'],
//           },
//         },
//       ],
//     });

//     if (!booking || !booking.Car) {
//       throw new Error('Unable to calculate price: Missing required car information');
//     }
//   }

//   const { pricePerMile, minimumStartFee } = booking.Car;
//   const percentage = booking.Gratuity ? booking.Gratuity.percentage : 0;

//   let carPrice =
//     Number(pricePerMile * booking.distanceInMiles) + Number(minimumStartFee);

//   const isRoundTrip =
//     booking.tripType === "Ride to the airport(round trip)" ||
//     booking.tripType === "Ride from the airport(round trip)";
//   if (isRoundTrip) carPrice *= 2;

//   let additionalStopPrice = booking.AdditionalStopOnTheWay
//     ? booking.AdditionalStopOnTheWay.additionalStopPrice
//     : 0;

//   let airportPickupPreferencePrice = booking.AirportPickupPreference
//     ? booking.AirportPickupPreference.preferencePrice
//     : 0;

//   let extraOptionsPrice = 0;
//   if (booking.ExtraOptions && booking.ExtraOptions.length > 0) {
//     if (isRoundTrip) {
//       booking.ExtraOptions.forEach(extraOption => {
//         extraOptionsPrice +=
//           extraOption.pricePerItem * extraOption.AirportBookExtraOption.quantity;
//       });
//       extraOptionsPrice *= 2;
//     } else {
//       booking.ExtraOptions.forEach(extraOption => {
//         extraOptionsPrice +=
//           extraOption.pricePerItem * extraOption.AirportBookExtraOption.quantity;
//       });
//     }
//   }

//   const tripPrice =
//     Number(carPrice) +
//     Number(additionalStopPrice) +
//     Number(airportPickupPreferencePrice) +
//     Number(extraOptionsPrice);

//   const totalPrice = percentage ? tripPrice + tripPrice * (percentage / 100) : tripPrice;
//   return Number(totalPrice.toFixed(2));
// }

// module.exports = {
//   searchUserBookingsByUserId,
//   calculateP2PTotalTripPrice,
//   calculateHourlyCharterTotalTripPrice,
//   calculateAirportBookingTotalTripPrice,
//   getPaymentDetailByUserId,
// };


const { HourlyCharterBook } = require("../models/HourlyCharterBook.js");
const { PointToPointBook } = require("../models/PointToPointBook.js");
const { AirportBook } = require("../models/airportBooking/AirportBook.js");
const { PaymentDetail } = require("../models/PaymentDetail.js");
const { Car } = require("../models/Car.js");
const { Op } = require("sequelize");
const { Gratuity } = require("../models/Gratuity.js");
const { AdditionalStopOnTheWay } = require("../models/booking/AdditionalStopOnTheWay.js");
const { AirportPickupPreference } = require("../models/airportBooking/AirportPickupPreference.js");
const { ExtraOption } = require("../models/ExtraOption.js");
const { SidePickDetour } = require("../models/booking/SidePickDetour.js");
const { getSideDetourSettings } = require("./sideDetourSettingsService.js");
const {
  getHourlyLongDistanceSettings,
} = require("./hourlyLongDistanceSettingsService.js");

// Define a function to search user bookings by user ID
async function searchUserBookingsByUserId(userId) {
  // Define options for querying
  const queryOptions = {
    where: {
      userId: userId,
      deletedAt: { [Op.is]: null }, // Filter out soft-deleted records
    },
    order: [["updatedAt", "DESC"]],
    attributes: { exclude: ["deletedAt"] },
    include: [
      {
        model: Car, // Include the Car model
        attributes: ["carId", "carName", "carImageUrl"],
        // Car is paranoid (soft-delete): once a car is retired from the
        // fleet, a plain include silently drops it and this booking's Car
        // comes back null even though the booking itself is still valid.
        // Past/current bookings should keep showing the car they were
        // actually booked with.
        paranoid: false,
      },
    ],
  };

  // Search point-to-point bookings
  const pointToPointBookings = await PointToPointBook.findAll(queryOptions);

  // Search hourly charter bookings
  const hourlyCharterBookings = await HourlyCharterBook.findAll(queryOptions);

  // Search airport bookings
  const airportBookings = await AirportBook.findAll(queryOptions);

  return {
    pointToPointBookings,
    hourlyCharterBookings,
    airportBookings,
  };
}

async function getPaymentDetailByUserId(userId) {
 const queryOptions = {
  where: {
    userId: userId,
    // deletedAt: { [Op.is]: null },
  },
  order: [["updatedAt", "DESC"]],
  // attributes: { exclude: ["deletedAt"] },
 };
 
 const paymentDetail = await PaymentDetail.findAll(queryOptions);
 
 return paymentDetail;
 
 
 
}

const {
  calculatePointToPointFare,
  calculateHourlyCharterFare,
  calculateAirportFare,
  carHasFareRates,
  longDistanceFeeFor,
} = require("../utils/bookingFareCalculator.js");

async function ensureAirportBookingForFare(booking) {
  if (carHasFareRates(booking.Car)) return booking;

  const reloaded = await AirportBook.findByPk(booking.airportBookId, {
    include: [
      {
        model: Car,
        attributes: ["pricePerMile", "pricePerHour", "minimumStartFee"],
        // See note in searchUserBookingsByUserId — a retired (soft-deleted)
        // car must still resolve so fare recalculation doesn't break for
        // existing bookings.
        paranoid: false,
      },
      { model: Gratuity, attributes: ["percentage"] },
      {
        model: AdditionalStopOnTheWay,
        attributes: ["additionalStopPrice"],
      },
      {
        model: AirportPickupPreference,
        attributes: ["preferencePrice"],
      },
      {
        model: ExtraOption,
        through: { attributes: ["quantity"] },
      },
    ],
  });

  if (!reloaded?.Car) {
    throw new Error("Unable to calculate price: Missing required car information");
  }
  return reloaded;
}

async function ensurePointToPointBookingForFare(booking) {
  if (carHasFareRates(booking.Car)) return booking;
  const reloaded = await PointToPointBook.findByPk(booking.pointToPointBookId, {
    include: [
      {
        model: Car,
        attributes: ["pricePerMile", "pricePerHour", "minimumStartFee"],
        // See note in searchUserBookingsByUserId — a retired (soft-deleted)
        // car must still resolve so fare recalculation doesn't break for
        // existing bookings.
        paranoid: false,
      },
      { model: Gratuity, attributes: ["percentage"] },
      {
        model: AdditionalStopOnTheWay,
        attributes: ["additionalStopPrice"],
      },
      {
        model: ExtraOption,
        through: { attributes: ["quantity"] },
      },
    ],
  });
  if (!reloaded?.Car) {
    throw new Error("Unable to calculate price: Missing required car information");
  }
  return reloaded;
}

async function ensureHourlyCharterBookingForFare(booking) {
  if (carHasFareRates(booking.Car)) return booking;
  const reloaded = await HourlyCharterBook.findByPk(booking.hourlyCharterBookId, {
    include: [
      {
        model: Car,
        attributes: ["pricePerMile", "pricePerHour", "minimumStartFee"],
        // See note in searchUserBookingsByUserId — a retired (soft-deleted)
        // car must still resolve so fare recalculation doesn't break for
        // existing bookings.
        paranoid: false,
      },
      { model: Gratuity, attributes: ["percentage"] },
      {
        model: ExtraOption,
        through: { attributes: ["quantity"] },
      },
    ],
  });
  if (!reloaded?.Car) {
    throw new Error("Unable to calculate price: Missing required car information");
  }
  return reloaded;
}

/**
 * Counted with an explicit, always-run query rather than relying on
 * `booking.SidePickDetours` being eager-loaded — ensurePointToPointBookingForFare/
 * ensureAirportBookingForFare only reload the booking (and so only pick up
 * associations) when the Car rate card is missing, which has nothing to do
 * with whether side picks exist. This is the actual charge path, so it can't
 * depend on that unrelated optimization happening to also load side picks.
 */
async function sideDetourFareOptsFor(pointToPointBookId, airportBookId) {
  const count = await SidePickDetour.count({
    where: pointToPointBookId ? { pointToPointBookId } : { airportBookId },
  });
  if (count === 0) return { sideDetourCount: 0 };
  const settings = await getSideDetourSettings();
  return {
    sideDetourCount: count,
    sideDetourSettings: { isActive: settings.isActive, startFee: settings.startFee },
  };
}

/**
 * Hourly Charter's Long Distance Fee opts — always fetched fresh (no cheap
 * existence check like sideDetourFareOptsFor's SidePickDetour.count, since
 * distance is computed straight from the booking's own pickup/drop-off
 * coordinates, already on hand with no extra query needed).
 */
async function longDistanceFareOptsFor() {
  const settings = await getHourlyLongDistanceSettings();
  return {
    longDistanceSettings: {
      isActive: settings.isActive,
      minimumDistanceInMiles: settings.minimumDistanceInMiles,
      feeAmount: settings.feeAmount,
    },
  };
}

/** The actual dollar amount (0 if inactive or under threshold) for one booking. */
async function getHourlyLongDistanceFeeForBooking(booking) {
  const opts = await longDistanceFareOptsFor();
  return longDistanceFeeFor(booking, opts);
}

/**
 * `discount` is optional and defaults to 0, which makes every one of these
 * three functions behave exactly as they did before a promo discount was
 * threaded through — every existing caller that doesn't pass one (fare
 * recalculation, admin manual-discount stacking, Square payment amount
 * lookups, the various fare-preview routes) is unaffected. Only the actual
 * booking-creation flow passes a real discount, once it's known (see
 * calculateP2PSubtotal below for how that discount itself gets computed).
 */
async function calculateP2PTotalTripPrice(booking, { discount = 0 } = {}) {
  const hydrated = await ensurePointToPointBookingForFare(booking);
  const opts = await sideDetourFareOptsFor(booking.pointToPointBookId, null);
  const { total } = calculatePointToPointFare(hydrated, { ...opts, discount });
  return total;
}

async function calculateHourlyCharterTotalTripPrice(booking, { discount = 0 } = {}) {
  const hydrated = await ensureHourlyCharterBookingForFare(booking);
  const opts = await longDistanceFareOptsFor();
  const { total } = calculateHourlyCharterFare(hydrated, { ...opts, discount });
  return total;
}

async function calculateAirportBookingTotalTripPrice(booking, { discount = 0 } = {}) {
  const hydrated = await ensureAirportBookingForFare(booking);
  const opts = await sideDetourFareOptsFor(null, booking.airportBookId);
  const { total } = calculateAirportFare(hydrated, { ...opts, discount });
  return total;
}

/**
 * The ride's own pre-gratuity, pre-discount subtotal — what a promo code's
 * percentage/flat amount should be computed against (see
 * promoCodeService.validatePromoCode's `fareAmount` param), so a discount
 * never eats into gratuity and gratuity can then be computed on the
 * discounted subtotal below it (see calculatePointToPointFare's
 * `discountedLegCarFare`).
 */
async function calculateP2PSubtotal(booking) {
  const hydrated = await ensurePointToPointBookingForFare(booking);
  const opts = await sideDetourFareOptsFor(booking.pointToPointBookId, null);
  const { breakdown } = calculatePointToPointFare(hydrated, opts);
  return breakdown.subtotal;
}

async function calculateHourlyCharterSubtotal(booking) {
  const hydrated = await ensureHourlyCharterBookingForFare(booking);
  const opts = await longDistanceFareOptsFor();
  const { breakdown } = calculateHourlyCharterFare(hydrated, opts);
  return breakdown.subtotal;
}

async function calculateAirportBookingSubtotal(booking) {
  const hydrated = await ensureAirportBookingForFare(booking);
  const opts = await sideDetourFareOptsFor(null, booking.airportBookId);
  const { breakdown } = calculateAirportFare(hydrated, opts);
  return breakdown.subtotal;
}

module.exports = {
  searchUserBookingsByUserId,
  calculateP2PTotalTripPrice,
  calculateHourlyCharterTotalTripPrice,
  calculateAirportBookingTotalTripPrice,
  calculateP2PSubtotal,
  calculateHourlyCharterSubtotal,
  calculateAirportBookingSubtotal,
  getPaymentDetailByUserId,
  getHourlyLongDistanceFeeForBooking,
};










