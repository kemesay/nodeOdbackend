/**
 * Canonical trip fare math — keep in sync with oda-ride-transport/src/utils/bookingFeeCalculator.js
 * and oda-black-car-service/lib/core/utils/pricing_calculator.dart
 */

function asMoney(value) {
  if (value == null || value === "") return 0;
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

function roundMoney(value) {
  return Number(asMoney(value).toFixed(2));
}

/**
 * Parse a dollar amount for Square (accepts DECIMAL strings from Sequelize).
 * @returns {number|null} positive dollars rounded to 2 decimals, or null if invalid
 */
function parsePaymentAmountDollars(value) {
  if (value == null || value === "") return null;
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0) return null;
  return roundMoney(n);
}

function isRoundTripTripType(tripType) {
  const t = String(tripType || "");
  return (
    t === "Round-Trip" ||
    t === "Ride to the airport(round trip)" ||
    t === "Ride from the airport(round trip)"
  );
}

/**
 * One-way leg vehicle fare from car rate card.
 * P2P / Airport: pricePerMile × miles + minimumStartFee
 * Hourly: pricePerHour × hours (minimum start fee is not added on hourly)
 */
function legCarFareFromCar(car, { bookingKind, distanceInMiles, selectedHours }) {
  if (!car) return 0;

  const pricePerMile = asMoney(car.pricePerMile);
  const pricePerHour = asMoney(car.pricePerHour);
  const minimumStartFee = asMoney(car.minimumStartFee);

  if (bookingKind === "HOURLY") {
    const hours = Math.max(asMoney(selectedHours), 0);
    return roundMoney(pricePerHour * hours);
  }

  const miles = Math.max(asMoney(distanceInMiles), 0);
  return roundMoney(pricePerMile * miles + minimumStartFee);
}

function gratuityOnCarFare(legCarFare, percentage, tripType) {
  const pct = asMoney(percentage);
  if (pct <= 0) return 0;
  const perLeg = legCarFare * (pct / 100);
  return roundMoney(isRoundTripTripType(tripType) ? perLeg * 2 : perLeg);
}

/**
 * A promo discount reduces the ride's own cost — gratuity should be a tip
 * on what the ride actually costs after that discount, not on the
 * pre-discount sticker price. `legCarFare` is scaled down by whatever
 * fraction of the discount falls on the car-fare portion of the subtotal
 * (proportional to its share — extras/stops/side-detour fees are never
 * part of the gratuity base, discounted or not, same as before), so this
 * reduces to exactly `legCarFare` when there's no discount at all —
 * undiscounted bookings compute gratuity exactly as they always have.
 */
function discountedLegCarFare(legCarFare, subtotal, discount) {
  if (!discount || subtotal <= 0) return legCarFare;
  const legCarShareOfDiscount = roundMoney((discount * legCarFare) / subtotal);
  return roundMoney(Math.max(legCarFare - legCarShareOfDiscount, 0));
}

/**
 * Optional per-stop fee for a booking that has side-pick detour stops —
 * startFee is charged for EACH detour stop (3 stops = 3x the fee), not once
 * per booking — and, like additionalStopPrice, never doubled for round trip.
 * Off by default; an admin turns it on and sets the per-stop amount from
 * Side Detour Settings (see sideDetourSettingsService.js).
 *
 * `sideDetourCount`/`sideDetourSettings` are meant to be passed explicitly by
 * the caller (the only way to guarantee correctness for the actual charge —
 * see calculateP2PTotalTripPrice/calculateAirportBookingTotalTripPrice in
 * utilTripService.js). When omitted, falls back to booking.SidePickDetours
 * if that association happens to already be loaded (best-effort, used by
 * secondary/display call sites like the confirmation email).
 */
function sideDetourFeeFor(booking, { sideDetourCount, sideDetourSettings } = {}) {
  if (!sideDetourSettings?.isActive) return 0;
  const count =
    sideDetourCount != null
      ? sideDetourCount
      : Array.isArray(booking.SidePickDetours)
        ? booking.SidePickDetours.length
        : 0;
  return count > 0 ? roundMoney(count * sideDetourSettings.startFee) : 0;
}

/** Great-circle ("as the crow flies") distance in miles between two points. */
function haversineDistanceMiles(lat1, lon1, lat2, lon2) {
  if ([lat1, lon1, lat2, lon2].some((v) => v == null || v === "")) return 0;
  const toRad = (deg) => (deg * Math.PI) / 180;
  const EARTH_RADIUS_MILES = 3958.8;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return EARTH_RADIUS_MILES * c;
}

/**
 * Flat "Long Distance Fee" added once when an Hourly Charter booking's
 * pickup and drop-off are farther apart (straight-line) than the admin's
 * configured minimum — e.g. a charter that starts or ends well outside the
 * normal service area. Computed server-side from the booking's own
 * coordinates, never trusted from the client. Off by default; an admin
 * turns it on and sets both the distance threshold and the fee from
 * Long Distance Settings (see hourlyLongDistanceSettingsService.js).
 *
 * `longDistanceSettings` is meant to be passed explicitly by the caller
 * (see longDistanceFareOptsFor in utilTripService.js) — the only way to
 * guarantee correctness for the actual charge.
 */
function longDistanceFeeFor(booking, { longDistanceSettings } = {}) {
  if (!longDistanceSettings?.isActive) return 0;
  const distance = haversineDistanceMiles(
    booking.pickupLatitude,
    booking.pickupLongitude,
    booking.dropoffLatitude,
    booking.dropoffLongitude
  );
  return distance > asMoney(longDistanceSettings.minimumDistanceInMiles)
    ? roundMoney(longDistanceSettings.feeAmount)
    : 0;
}

function sumExtraOptionsPrice(extraOptions, throughKey, { roundTrip }) {
  if (!extraOptions) return 0;

  const list = Array.isArray(extraOptions)
    ? extraOptions
    : Object.values(extraOptions);

  let total = 0;
  for (const option of list) {
    if (!option) continue;
    const junction = option[throughKey];
    const qty = asMoney(junction?.quantity);
    const unit = asMoney(option.pricePerItem);
    if (qty <= 0) continue;
    total += unit * qty;
  }

  if (roundTrip) total *= 2;
  return roundMoney(total);
}

function detectBookingKind(booking) {
  if (booking.hourlyCharterBookId != null || booking.selectedHours != null) {
    if (booking.airportBookId == null && booking.pointToPointBookId == null) {
      return "HOURLY";
    }
    if (booking.selectedHours != null && !booking.distanceInMiles) {
      return "HOURLY";
    }
  }
  if (booking.airportBookId != null) return "AIRPORT";
  if (booking.pointToPointBookId != null) return "P2P";
  if (booking.selectedHours != null && !booking.distanceInMiles) return "HOURLY";
  return "P2P";
}

function assertCarForFare(car) {
  if (!car) {
    throw new Error("Unable to calculate price: missing car (carId / rate card).");
  }
  const kind = car.pricePerHour > 0 || car.pricePerMile > 0;
  if (!kind && asMoney(car.minimumStartFee) <= 0) {
    throw new Error("Unable to calculate price: car rate card has no pricing fields.");
  }
}

/** True when Car association includes at least one pricing column (not just image/name). */
function carHasFareRates(car) {
  if (!car) return false;
  return (
    car.pricePerMile != null ||
    car.pricePerHour != null ||
    car.minimumStartFee != null
  );
}

/**
 * @returns {{ total: number, breakdown: object }}
 */
function calculatePointToPointFare(booking, opts) {
  assertCarForFare(booking.Car);
  const roundTrip = booking.tripType === "Round-Trip";
  const legCar = legCarFareFromCar(booking.Car, {
    bookingKind: "P2P",
    distanceInMiles: booking.distanceInMiles,
  });
  const carFare = roundMoney(legCar * (roundTrip ? 2 : 1));

  const additionalStopPrice = booking.AdditionalStopOnTheWay
    ? asMoney(booking.AdditionalStopOnTheWay.additionalStopPrice)
    : 0;

  const sideDetourFee = sideDetourFeeFor(booking, opts);

  const extraOptionsPrice = sumExtraOptionsPrice(
    booking.ExtraOptions,
    "PointToPointBookExtraOption",
    { roundTrip }
  );

  const subtotal = roundMoney(
    carFare + additionalStopPrice + sideDetourFee + extraOptionsPrice
  );

  // Capped at the subtotal itself — a discount can never make gratuity or
  // the final total negative. 0 when no promo code applied (opts.discount
  // omitted), which is also what makes every calculation below reduce to
  // exactly the pre-discount behavior.
  const discount = roundMoney(Math.min(Math.max(asMoney(opts?.discount), 0), subtotal));
  const discountedSubtotal = roundMoney(subtotal - discount);

  const gratuityPct = asMoney(booking.Gratuity?.percentage);
  const gratuity = gratuityOnCarFare(
    discountedLegCarFare(legCar, subtotal, discount),
    gratuityPct,
    booking.tripType
  );
  const total = roundMoney(discountedSubtotal + gratuity);

  return {
    total,
    breakdown: {
      legCarFare: legCar,
      carFare,
      additionalStopPrice,
      sideDetourFee,
      extraOptionsPrice,
      discount,
      subtotal,
      discountedSubtotal,
      gratuity,
    },
  };
}

function calculateHourlyCharterFare(booking, opts) {
  assertCarForFare(booking.Car);
  const legCar = legCarFareFromCar(booking.Car, {
    bookingKind: "HOURLY",
    selectedHours: booking.selectedHours,
  });
  const carFare = legCar;

  const extraOptionsPrice = sumExtraOptionsPrice(
    booking.ExtraOptions,
    "HourlyCharterBookExtraOption",
    { roundTrip: false }
  );

  const longDistanceFee = longDistanceFeeFor(booking, opts);

  const subtotal = roundMoney(carFare + extraOptionsPrice + longDistanceFee);

  const discount = roundMoney(Math.min(Math.max(asMoney(opts?.discount), 0), subtotal));
  const discountedSubtotal = roundMoney(subtotal - discount);

  const gratuityPct = asMoney(booking.Gratuity?.percentage);
  const gratuity = gratuityOnCarFare(
    discountedLegCarFare(legCar, subtotal, discount),
    gratuityPct,
    booking.tripType
  );
  const total = roundMoney(discountedSubtotal + gratuity);

  return {
    total,
    breakdown: {
      legCarFare: legCar,
      carFare,
      extraOptionsPrice,
      longDistanceFee,
      discount,
      subtotal,
      discountedSubtotal,
      gratuity,
    },
  };
}

function calculateAirportFare(booking, opts) {
  assertCarForFare(booking.Car);
  const roundTrip = isRoundTripTripType(booking.tripType);
  const legCar = legCarFareFromCar(booking.Car, {
    bookingKind: "AIRPORT",
    distanceInMiles: booking.distanceInMiles,
  });
  const carFare = roundMoney(legCar * (roundTrip ? 2 : 1));

  const additionalStopPrice = booking.AdditionalStopOnTheWay
    ? asMoney(booking.AdditionalStopOnTheWay.additionalStopPrice)
    : 0;

  const airportPickupPreferencePrice = booking.AirportPickupPreference
    ? asMoney(booking.AirportPickupPreference.preferencePrice)
    : 0;

  const sideDetourFee = sideDetourFeeFor(booking, opts);

  const extraOptionsPrice = sumExtraOptionsPrice(
    booking.ExtraOptions,
    "AirportBookExtraOption",
    { roundTrip }
  );

  const subtotal = roundMoney(
    carFare +
      additionalStopPrice +
      airportPickupPreferencePrice +
      sideDetourFee +
      extraOptionsPrice
  );

  const discount = roundMoney(Math.min(Math.max(asMoney(opts?.discount), 0), subtotal));
  const discountedSubtotal = roundMoney(subtotal - discount);

  const gratuityPct = asMoney(booking.Gratuity?.percentage);
  const gratuity = gratuityOnCarFare(
    discountedLegCarFare(legCar, subtotal, discount),
    gratuityPct,
    booking.tripType
  );
  const total = roundMoney(discountedSubtotal + gratuity);

  return {
    total,
    breakdown: {
      legCarFare: legCar,
      carFare,
      additionalStopPrice,
      airportPickupPreferencePrice,
      sideDetourFee,
      extraOptionsPrice,
      discount,
      subtotal,
      discountedSubtotal,
      gratuity,
    },
  };
}

/**
 * Extra-time charge for LIVE billing mode — time beyond the booked/base hours.
 * Plain linear rate: pricePerHour × extraHours. No overtime premium/multiplier —
 * the customer pays the same per-hour rate whether under, at, or over their
 * booked hours (the booked-hours minimum charge is enforced by the caller).
 */
function calculateExtraTimeFare(pricePerHour, extraHours) {
  const hours = Math.max(asMoney(extraHours), 0);
  if (hours <= 0) return 0;
  return roundMoney(asMoney(pricePerHour) * hours);
}

/**
 * Pre-authorization amount for LIVE billing mode.
 * Authorizes (selectedHours + bufferHours) so the card hold covers overtime.
 * `longDistanceFee` (flat, known at booking time — see longDistanceFeeFor)
 * is included here too, not just gratuity base, so the hold is never short
 * of what endHourlyTrip ends up charging for a long-distance LIVE booking.
 */
function calculateLiveModePreAuthAmount({
  car,
  selectedHours,
  bufferHours = 2,
  gratuityPercentage = 0,
  extraOptionsPerLeg = 0,
  longDistanceFee = 0,
}) {
  assertCarForFare(car);
  const totalHours = asMoney(selectedHours) + asMoney(bufferHours);
  const legCar = roundMoney(asMoney(car.pricePerHour) * totalHours);
  const extras = roundMoney(asMoney(extraOptionsPerLeg));
  const subtotal = roundMoney(legCar + extras + asMoney(longDistanceFee));
  const gratuity = gratuityOnCarFare(legCar, gratuityPercentage);
  return roundMoney(subtotal + gratuity);
}

function calculateBookingFare(booking, bookingKind, opts) {
  const kind =
    bookingKind ||
    (booking.hourlyCharterBookId != null
      ? "HOURLY"
      : booking.airportBookId != null
        ? "AIRPORT"
        : detectBookingKind(booking));

  switch (kind) {
    case "HOURLY":
    case "HOURLY_CHARTER":
      return calculateHourlyCharterFare(booking, opts);
    case "AIRPORT":
      return calculateAirportFare(booking, opts);
    case "P2P":
    case "POINT_TO_POINT":
    default:
      return calculatePointToPointFare(booking, opts);
  }
}

/**
 * Quote from raw inputs (for POST /bookings/quote and client previews).
 */
function quoteFare({
  bookingKind,
  car,
  tripType,
  distanceInMiles,
  selectedHours,
  gratuityPercentage = 0,
  additionalStopPrice = 0,
  airportPickupPreferencePrice = 0,
  extraOptionsPerLeg = 0,
  sideDetourFee = 0,
}) {
  assertCarForFare(car);
  const kind = String(bookingKind || "P2P").toUpperCase();
  const roundTrip = isRoundTripTripType(tripType);

  if (kind === "HOURLY" || kind === "HOURLY_CHARTER") {
    const legCar = legCarFareFromCar(car, {
      bookingKind: "HOURLY",
      selectedHours,
    });
    const extras = roundMoney(asMoney(extraOptionsPerLeg));
    const subtotal = roundMoney(legCar + extras);
    const gratuity = gratuityOnCarFare(legCar, gratuityPercentage, tripType);
    return {
      total: roundMoney(subtotal + gratuity),
      legCarFare: legCar,
      extraOptionsPrice: extras,
      subtotal,
      gratuity,
    };
  }

  const legCar = legCarFareFromCar(car, {
    bookingKind: kind === "AIRPORT" ? "AIRPORT" : "P2P",
    distanceInMiles,
  });
  const carFare = roundMoney(legCar * (roundTrip ? 2 : 1));
  const extras = roundMoney(asMoney(extraOptionsPerLeg) * (roundTrip ? 2 : 1));
  const resolvedAdditionalStopPrice = roundMoney(asMoney(additionalStopPrice));
  const resolvedAirportPickupPreferencePrice = roundMoney(asMoney(airportPickupPreferencePrice));
  const resolvedSideDetourFee = roundMoney(asMoney(sideDetourFee));
  const subtotal = roundMoney(
    carFare +
      resolvedAdditionalStopPrice +
      resolvedAirportPickupPreferencePrice +
      resolvedSideDetourFee +
      extras
  );
  const gratuity = gratuityOnCarFare(legCar, gratuityPercentage, tripType);
  return {
    total: roundMoney(subtotal + gratuity),
    legCarFare: legCar,
    carFare,
    additionalStopPrice: resolvedAdditionalStopPrice,
    airportPickupPreferencePrice: resolvedAirportPickupPreferencePrice,
    sideDetourFee: resolvedSideDetourFee,
    extraOptionsPrice: extras,
    subtotal,
    gratuity,
  };
}

module.exports = {
  asMoney,
  parsePaymentAmountDollars,
  roundMoney,
  isRoundTripTripType,
  legCarFareFromCar,
  gratuityOnCarFare,
  sideDetourFeeFor,
  longDistanceFeeFor,
  haversineDistanceMiles,
  carHasFareRates,
  calculatePointToPointFare,
  calculateHourlyCharterFare,
  calculateAirportFare,
  calculateBookingFare,
  quoteFare,
  calculateExtraTimeFare,
  calculateLiveModePreAuthAmount,
};
