// const { DataTypes } = require("sequelize");
// const Joi = require("joi");
// const { sequelize } = require("../../config/database.js");
// const { Car } = require("../Car.js");
// const { User } = require("../user/User.js");
// const AirportBookExtraOption = require("./AirportBookExtraOption.js");
// const { ExtraOption } = require("../ExtraOption.js");
// const { Gratuity } = require("../Gratuity.js");
// const { Airport } = require("./Airport.js");
// const {
//   AdditionalStopOnTheWay,
// } = require("../booking/AdditionalStopOnTheWay.js");
// const { AirportPickupPreference } = require("./AirportPickupPreference.js");

// const { PaymentDetail } = require("../PaymentDetail.js");

// const {
//   extraOptionSchema,
//   dateFormat,
//   dateFormatMessage,
//   testCards,
//   creditCardNumberMessage,
//   expirationDateMessage,
//   securityCodeMessage,
// } = require("../../utils/validationUtils");

// const AirportBook = sequelize.define(
//   "AirportBook",
//   {
//     airportBookId: {
//       type: DataTypes.BIGINT,
//       primaryKey: true,
//       autoIncrement: true,
//       allowNull: false,
//     },
//     confirmationNumber: {
//       type: DataTypes.STRING,
//       allowNull: false,
//       unique: true,
//     },
//     tripType: {
//       type: DataTypes.ENUM(
//         "Ride to the airport(one way)",
//         "Ride from the airport(one way)",
//         "Ride to the airport(round trip)",
//         "Ride from the airport(round trip)"
//       ),
//       allowNull: false,
//     },

//     numberOfPassengers: {
//       type: DataTypes.INTEGER,
//     },
//     numberOfSuitcases: {
//       type: DataTypes.INTEGER,
//     },

//     accommodationAddress: {
//       type: DataTypes.STRING,
//       allowNull: false,
//     },
//     accommodationLongitude: {
//       type: DataTypes.FLOAT,
//       allowNull: false,
//     },
//     accommodationLatitude: {
//       type: DataTypes.FLOAT,
//       allowNull: false,
//     },

//     airline: {
//       type: DataTypes.STRING,
//     },

//     arrivalFlightNumber: {
//       type: DataTypes.STRING,
//     },

//     returnAirline: {
//       type: DataTypes.STRING,
//     },

//     returnFlightNumber: {
//       type: DataTypes.STRING,
//     },

//     specialInstructions: {
//       type: DataTypes.TEXT,
//     },

//     pickupDateTime: {
//       type: DataTypes.DATE,
//       set(value) {
//         const date = new Date(value);
//         date.setSeconds(0);
//         this.setDataValue("pickupDateTime", date);
//       },
//     },

//     returnPickupDateTime: {
//       type: DataTypes.DATE,
//       set(value) {
//         const date = new Date(value);
//         date.setSeconds(0);
//         this.setDataValue("returnPickupDateTime", date);
//       },
//     },

//     distanceInMiles: {
//       type: DataTypes.DOUBLE,
//       allowNull: false,
//     },

//     additionalStopOnTheWayDescription: {
//       type: DataTypes.TEXT,
//     },

//     isGuestBooking: {
//       type: DataTypes.BOOLEAN,
//       defaultValue: false,
//     },
//     bookingFor: {
//       type: DataTypes.ENUM("Myself", "SomeoneElse"),
//       allowNull: false,
//       defaultValue: "Myself",
//     },
//     passengerFullName: {
//       type: DataTypes.STRING,
//       allowNull: false,
//       validate: {
//         len: [2, 100],
//       },
//     },
//     paymentMethod: {
//       type: DataTypes.ENUM("PRIMARY_CARD", "EXISTING_CARD", "NEW_CARD"),
//       allowNull: false,
//     },
//     passengerCellPhone: {
//       type: DataTypes.STRING,
//       allowNull: false,
//       validate: {
//         is: /^[0-9]{10,15}$/,
//       },
//     },
//     passengerEmail: {
//       type: DataTypes.STRING,
//       allowNull: false,
//       validate: {
//         isEmail: true,
//         len: [1, 255],
//       },
//     },

//     totalTripFeeInDollars: {
//       type: DataTypes.DECIMAL(10, 2),
//       validate: {
//         min: {
//           args: [1],
//         },
//       },
//     },

//     paymentStatus: {
//       type: DataTypes.ENUM(
//         "NOT_PAID",
//         "AWAITING_PAYMENT",
//         "PARTIALLY_PAID",
//         "PAID",
//         "PENDING_REFUND",
//         "REFUNDED",
//         "CANCELLED"
//       ),
//       defaultValue: "NOT_PAID",
//     },

//     bookingStatus: {
//       type: DataTypes.ENUM(
//         "PENDING_APPROVAL",
//         "UNDER_REVIEW",
//         "ACCEPTED",
//         "REJECTED",
//         "CANCELLED",
//         "AWAITING_PICKUP",
//         "PICKUP_COMPLETED",
//         "EN_ROUTE",
//         "AWAITING_RETURN_PICKUP",
//         "RETURN_PICKUP_COMPLETED",
//         "OVERDUE",
//         "DISPUTED",
//         "COMPLETED"
//       ),
//       defaultValue: "PENDING_APPROVAL",
//     },
//   },
//   {
//     sequelize,
//     modelName: "AirportBook",
//     tableName: "airport_books",
//     paranoid: true,
//   }
// );

// // Define association with PaymentDetail model
// AirportBook.belongsTo(PaymentDetail, { 
//   foreignKey: "paymentDetailId",
//   targetKey: "paymentDetailId"
// });

// // Define association with User model
// AirportBook.belongsTo(User, { foreignKey: "userId" });

// // Define association with Airport model
// AirportBook.belongsTo(Airport, { foreignKey: "airportId" });

// // Define association with Car model
// AirportBook.belongsTo(Car, { foreignKey: "carId" });

// // Define association with Gratuity model
// AirportBook.belongsTo(Gratuity, { foreignKey: "gratuityId" });

// // Define association with AdditionalStopOnTheWay model
// AirportBook.belongsTo(AdditionalStopOnTheWay, {
//   foreignKey: "additionalStopId",
// });

// // Define association with AdditionalStopOnTheWay model
// AirportBook.belongsTo(AirportPickupPreference, {
//   foreignKey: "pickupPreferenceId",
// });

// // Associate AirportBook with ExtraOption through BookExtraOption
// AirportBook.belongsToMany(ExtraOption, {
//   through: AirportBookExtraOption,
//   foreignKey: "airportBookId",
//   otherKey: "extraOptionId",
//   uniqueKey: "airport_book_extra_options_unique",
// });

// ExtraOption.belongsToMany(AirportBook, {
//   through: AirportBookExtraOption,
//   foreignKey: "extraOptionId",
//   otherKey: "airportBookId",
//   uniqueKey: "airport_book_extra_options_unique",
// });

// const cardDetailsSchema = Joi.object({
//   creditCardNumber: Joi.string()
//     .creditCard()
//     .required()
//     .messages({
//       'string.creditCard': 'Invalid credit card number',
//       'any.required': 'Credit card number is required'
//     }),
//   expirationDate: Joi.string()
//     .pattern(/^(0[1-9]|1[0-2])\/([0-9]{2})$/)
//     .required()
//     .custom((value, helpers) => {
//       const [month, year] = value.split('/');
//       const currentYear = new Date().getFullYear() % 100;
//       const currentMonth = new Date().getMonth() + 1;
      
//       // Convert YY to full year (2000 + YY)
//       const fullYear = 2000 + parseInt(year, 10);
      
//       // Check if expiration date is in the future
//       if (
//         fullYear < new Date().getFullYear() || 
//         (fullYear === new Date().getFullYear() && parseInt(month, 10) < currentMonth)
//       ) {
//         return helpers.error('date.expired');
//       }
      
//       return value;
//     })
//     .messages({
//       'string.pattern.base': 'Expiration date must be in MM/YY format',
//       'date.expired': 'Card has expired',
//       'any.required': 'Expiration date is required'
//     }),
//   securityCode: Joi.string()
//     .pattern(/^[0-9]{3,4}$/)
//     .required()
//     .messages({
//       'string.pattern.base': 'Security code must be 3 or 4 digits',
//       'any.required': 'Security code is required'
//     }),
//   zipCode: Joi.string()
//     .pattern(/^[0-9]{5}(?:-[0-9]{4})?$/)
//     .required()
//     .messages({
//       'string.pattern.base': 'Invalid ZIP code format',
//       'any.required': 'ZIP code is required'
//     }),
//   cardOwnerName: Joi.string()
//     .min(2)
//     .max(100)
//     .pattern(/^[a-zA-Z\s]+$/)
//     .required()
//     .messages({
//       'string.min': 'Cardholder name must be at least 2 characters',
//       'string.max': 'Cardholder name must be less than 100 characters',
//       'string.pattern.base': 'Cardholder name can only contain letters and spaces',
//       'any.required': 'Cardholder name is required'
//     })
// });
// function validateAirportBook(airportBook) {
//   const schema = Joi.object({
//     tripType: Joi.string()
//       .valid(
//         "Ride to the airport(one way)",
//         "Ride from the airport(one way)",
//         "Ride to the airport(round trip)",
//         "Ride from the airport(round trip)"
//       )
//       .required(),
//     numberOfPassengers: Joi.number().integer().min(1).required(),
//     accommodationAddress: Joi.string().required(),
//     accommodationLongitude: Joi.number().required(),
//     accommodationLatitude: Joi.number().required(),
//     pickupDateTime: Joi.string()
//       .regex(dateFormat)
//       .message("Invalid pickup Date format. " + dateFormatMessage)
//       .required(),
//     distanceInMiles: Joi.number().precision(2).required(),
//     passengerFullName: Joi.string().min(2).max(100).required(),
//     passengerEmail: Joi.string().email().max(255).required(),
//     passengerCellPhone: Joi.string()
//       .pattern(/^[0-9]{10,15}$/)
//       .message("Please provide a valid guest phone number.")
//       .required(),
//     numberOfSuitcases: Joi.number().integer().min(0).default(0),
//     isGuestBooking: Joi.boolean().default(false),
//     bookingFor: Joi.string().valid("Myself", "SomeoneElse").default("Myself"),
//     paymentMethod: Joi.string()
//       .valid("PRIMARY_CARD", "EXISTING_CARD", "NEW_CARD")
//       .default("NEW_CARD"),
//     airline: Joi.string().allow(""),
//     arrivalFlightNumber: Joi.string().allow(""),
//     returnAirline: Joi.string().allow(""),
//     returnFlightNumber: Joi.string().allow(""),
//     specialInstructions: Joi.string().allow(""),
//     carId: Joi.number().integer().allow(null),
//     gratuityId: Joi.number().integer().allow(null),
//     airportId: Joi.number().integer().allow(null),
//     extraOptions: Joi.array().items(extraOptionSchema).min(0),
//     pickupPreferenceId: Joi.number().integer().allow(null),
//     additionalStopId: Joi.number().integer().allow(null),
//     additionalStopOnTheWayDescription: Joi.string().allow(""),
//     paymentDetailId: Joi.number().integer().allow(null),
//     returnPickupDateTime: Joi.string()
//       .regex(dateFormat)
//       .message("Invalid return Pickup Date format. " + dateFormatMessage)
//       .when("tripType", {
//         is: Joi.string().valid(
//           "Ride to the airport(round trip)",
//           "Ride from the airport(round trip)"
//         ),
//         then: Joi.required(),
//         otherwise: Joi.allow(null),
//       }),
//     cardDetails: Joi.when('paymentMethod', {
//       is: 'NEW_CARD',
//       then: cardDetailsSchema.required(),
//       otherwise: Joi.forbidden()
//     }),
//     paymentDetailId: Joi.when('paymentMethod', {
//       is: 'EXISTING_CARD',
//       then: Joi.number().required(),
//       otherwise: Joi.forbidden()
//     })
//   });

//   return schema.validate(airportBook);
// }

// module.exports = { AirportBook, validateAirportBook };

const { DataTypes } = require("sequelize");
const Joi = require("joi");
const { sequelize } = require("../../config/database.js");
const { Car } = require("../Car.js");
const { User } = require("../user/User.js");
const AirportBookExtraOption = require("./AirportBookExtraOption.js");
const { ExtraOption } = require("../ExtraOption.js");
const { Gratuity } = require("../Gratuity.js");
const { Airport } = require("./Airport.js");
const {
  AdditionalStopOnTheWay,
} = require("../booking/AdditionalStopOnTheWay.js");
const { AirportPickupPreference } = require("./AirportPickupPreference.js");

const { PaymentDetail } = require("../PaymentDetail.js");

const {
  extraOptionSchema,
  dateFormat,
  dateFormatMessage,
  testCards,
  creditCardNumberMessage,
  expirationDateMessage,
  securityCodeMessage,
} = require("../../utils/validationUtils");

const AirportBook = sequelize.define(
  "AirportBook",
  {
    airportBookId: {
      type: DataTypes.BIGINT,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },
    confirmationNumber: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    tripType: {
      type: DataTypes.ENUM(
        "Ride to the airport(one way)",
        "Ride from the airport(one way)",
        "Ride to the airport(round trip)",
        "Ride from the airport(round trip)"
      ),
      allowNull: false,
    },

    numberOfPassengers: {
      type: DataTypes.INTEGER,
    },
    numberOfSuitcases: {
      type: DataTypes.INTEGER,
    },

    accommodationAddress: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    accommodationLongitude: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
    accommodationLatitude: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },

    /** When airportId is null: terminal / airport side from maps (same pattern as accommodation) */
    airportLocationAddress: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    airportLocationLatitude: {
      type: DataTypes.FLOAT,
      allowNull: true,
    },
    airportLocationLongitude: {
      type: DataTypes.FLOAT,
      allowNull: true,
    },

    airline: {
      type: DataTypes.STRING,
    },

    arrivalFlightNumber: {
      type: DataTypes.STRING,
    },

    returnAirline: {
      type: DataTypes.STRING,
    },

    returnFlightNumber: {
      type: DataTypes.STRING,
    },

    specialInstructions: {
      type: DataTypes.TEXT,
    },

    pickupDateTime: {
      type: DataTypes.DATE,
      set(value) {
        const date = new Date(value);
        date.setSeconds(0);
        this.setDataValue("pickupDateTime", date);
      },
    },

    returnPickupDateTime: {
      type: DataTypes.DATE,
      set(value) {
        const date = new Date(value);
        date.setSeconds(0);
        this.setDataValue("returnPickupDateTime", date);
      },
    },

    distanceInMiles: {
      type: DataTypes.DOUBLE,
      allowNull: false,
    },

    additionalStopOnTheWayDescription: {
      type: DataTypes.TEXT,
    },

    isGuestBooking: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    bookingFor: {
      type: DataTypes.ENUM("Myself", "SomeoneElse"),
      allowNull: false,
      defaultValue: "Myself",
    },
    passengerFullName: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        len: [2, 100],
      },
    },
    paymentMethod: {
      type: DataTypes.STRING(32),
      allowNull: false,
    },
    passengerCellPhone: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        is: /^[0-9]{10,15}$/,
      },
    },
    passengerEmail: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        isEmail: true,
        len: [1, 255],
      },
    },

    totalTripFeeInDollars: {
      type: DataTypes.DECIMAL(10, 2),
      validate: {
        min: {
          args: [1],
        },
      },
    },

    // Admin manual discount only (see applyDiscountToAirportBook). Kept
    // separate from promoDiscountAmountInDollars so one can never silently
    // overwrite the other — the two are always additive against a freshly
    // recomputed base fare.
    discountAmountInDollars: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true,
      defaultValue: 0.00,
      validate: {
        min: 0,
      },
    },
    // Promo-code discount only, frozen at booking-creation time.
    promoDiscountAmountInDollars: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true,
      defaultValue: 0.00,
      validate: {
        min: 0,
      },
    },
    // Wallet credit applied to this booking (see walletService.js) — a third
    // discount bucket, independent of and additive with the two above.
    walletCreditAppliedInDollars: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true,
      defaultValue: 0.00,
      validate: {
        min: 0,
      },
    },
    hasDiscountApplied: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },

    paymentStatus: {
      type: DataTypes.ENUM(
        "NOT_PAID",
        "AWAITING_PAYMENT",
        "AUTHORIZED",
        "PARTIALLY_PAID",
        "PAID",
        "PENDING_REFUND",
        "REFUNDED",
        "CANCELLED",
        "DISCOUNT_APPLIED"
      ),
      defaultValue: "NOT_PAID",
    },

    bookingStatus: {
      type: DataTypes.ENUM(
        "PENDING_APPROVAL",
        "UNDER_REVIEW",
        "ACCEPTED",
        "REJECTED",
        "CANCELLED",
        "AWAITING_PICKUP",
        "PICKUP_COMPLETED",
        "EN_ROUTE",
        "AWAITING_RETURN_PICKUP",
        "RETURN_PICKUP_COMPLETED",
        "OVERDUE",
        "DISPUTED",
        "COMPLETED"
      ),
      defaultValue: "PENDING_APPROVAL",
    },
  },
  {
    sequelize,
    modelName: "AirportBook",
    tableName: "airport_books",
    paranoid: true,
  }
);

// Define association with PaymentDetail model
AirportBook.belongsTo(PaymentDetail, { 
  foreignKey: "paymentDetailId",
  targetKey: "paymentDetailId"
});

// Define association with User model
AirportBook.belongsTo(User, { foreignKey: "userId" });

// Define association with Airport model
AirportBook.belongsTo(Airport, { foreignKey: "airportId" });

// Define association with Car model
AirportBook.belongsTo(Car, { foreignKey: "carId" });

// Define association with Gratuity model
AirportBook.belongsTo(Gratuity, { foreignKey: "gratuityId" });

// Define association with AdditionalStopOnTheWay model
AirportBook.belongsTo(AdditionalStopOnTheWay, {
  foreignKey: "additionalStopId",
});

// Define association with AdditionalStopOnTheWay model
AirportBook.belongsTo(AirportPickupPreference, {
  foreignKey: "pickupPreferenceId",
});

// Associate AirportBook with ExtraOption through BookExtraOption
AirportBook.belongsToMany(ExtraOption, {
  through: AirportBookExtraOption,
  foreignKey: "airportBookId",
  otherKey: "extraOptionId",
  uniqueKey: "airport_book_extra_options_unique",
});

ExtraOption.belongsToMany(AirportBook, {
  through: AirportBookExtraOption,
  foreignKey: "extraOptionId",
  otherKey: "airportBookId",
  uniqueKey: "airport_book_extra_options_unique",
});

const { SidePickDetour } = require("../booking/SidePickDetour.js");
AirportBook.hasMany(SidePickDetour, {
  foreignKey: "airportBookId",
  as: "SidePickDetours",
});
SidePickDetour.belongsTo(AirportBook, { foreignKey: "airportBookId" });

const cardDetailsSchema = Joi.object({
  creditCardNumber: Joi.string()
    .creditCard()
    .required()
    .messages({
      'string.creditCard': 'Invalid credit card number',
      'any.required': 'Credit card number is required'
    }),
  expirationDate: Joi.string()
    .pattern(/^(0[1-9]|1[0-2])\/([0-9]{2})$/)
    .required()
    .custom((value, helpers) => {
      const [month, year] = value.split('/');
      const currentYear = new Date().getFullYear() % 100;
      const currentMonth = new Date().getMonth() + 1;
      
      // Convert YY to full year (2000 + YY)
      const fullYear = 2000 + parseInt(year, 10);
      
      // Check if expiration date is in the future
      if (
        fullYear < new Date().getFullYear() || 
        (fullYear === new Date().getFullYear() && parseInt(month, 10) < currentMonth)
      ) {
        return helpers.error('date.expired');
      }
      
      return value;
    })
    .messages({
      'string.pattern.base': 'Expiration date must be in MM/YY format',
      'date.expired': 'Card has expired',
      'any.required': 'Expiration date is required'
    }),
  securityCode: Joi.string()
    .pattern(/^[0-9]{3,4}$/)
    .required()
    .messages({
      'string.pattern.base': 'Security code must be 3 or 4 digits',
      'any.required': 'Security code is required'
    }),
  zipCode: Joi.string()
    .pattern(/^[0-9]{5}(?:-[0-9]{4})?$/)
    .required()
    .messages({
      'string.pattern.base': 'Invalid ZIP code format',
      'any.required': 'ZIP code is required'
    }),
  cardOwnerName: Joi.string()
    .min(2)
    .max(100)
    .pattern(/^[a-zA-Z\s]+$/)
    .required()
    .messages({
      'string.min': 'Cardholder name must be at least 2 characters',
      'string.max': 'Cardholder name must be less than 100 characters',
      'string.pattern.base': 'Cardholder name can only contain letters and spaces',
      'any.required': 'Cardholder name is required'
    })
});

const validateAirportBook = Joi.object({
  tripType: Joi.string()
    .valid(
      "Ride to the airport(one way)",
      "Ride from the airport(one way)",
      "Ride to the airport(round trip)",
      "Ride from the airport(round trip)"
    )
    .required(),
  numberOfPassengers: Joi.number().integer().min(1).required(),
  accommodationAddress: Joi.string().required(),
  accommodationLongitude: Joi.number().required(),
  accommodationLatitude: Joi.number().required(),
  pickupDateTime: Joi.string()
    .regex(dateFormat)
    .message("Invalid pickup Date format. " + dateFormatMessage)
    .required(),
  distanceInMiles: Joi.number().precision(2).required(),
  passengerFullName: Joi.string().min(2).max(100).required(),
  passengerEmail: Joi.string().email().max(255).required(),
  passengerCellPhone: Joi.string()
    .pattern(/^[0-9]{10,15}$/)
    .message("Please provide a valid guest phone number.")
    .required(),
  numberOfSuitcases: Joi.number().integer().min(0).default(0),
  isGuestBooking: Joi.boolean().default(false),
  bookingFor: Joi.string().valid("Myself", "SomeoneElse").default("Myself"),
  paymentMethod: Joi.string()
    .valid(
      "PRIMARY_CARD",
      "EXISTING_CARD",
      "NEW_CARD",
      "SQUARE_NEW_CARD",
      "SQUARE_SAVED_CARD"
    )
    .default("SQUARE_NEW_CARD"),
  square: Joi.when("paymentMethod", {
    is: "SQUARE_NEW_CARD",
    then: Joi.object({
      sourceId: Joi.string().required(),
      verificationToken: Joi.string().allow("", null),
    }).required(),
    otherwise: Joi.forbidden(),
  }),
  squareCardId: Joi.when("paymentMethod", {
    is: "SQUARE_SAVED_CARD",
    then: Joi.string().optional(),
    otherwise: Joi.forbidden(),
  }),
  airline: Joi.string().allow(""),
  arrivalFlightNumber: Joi.string().allow(""),
  returnAirline: Joi.string().allow(""),
  returnFlightNumber: Joi.string().allow(""),
  specialInstructions: Joi.string().allow(""),
  carId: Joi.number().integer().allow(null),
  gratuityId: Joi.number().integer().allow(null),
  airportId: Joi.number().integer().positive().allow(null),
  /** Use with lat/lng when not sending airportId (free-form airport / terminal from Places API) */
  airportLocationAddress: Joi.string().allow("", null),
  airportLocationLatitude: Joi.number().allow(null),
  airportLocationLongitude: Joi.number().allow(null),
  extraOptions: Joi.array().items(extraOptionSchema).min(0),
  pickupPreferenceId: Joi.number().integer().allow(null),
  additionalStopId: Joi.number().integer().allow(null),
  additionalStopOnTheWayDescription: Joi.string().allow(""),
  sidePicks: Joi.array().items(
    Joi.object({
      address: Joi.string().required(),
      latitude: Joi.number().required(),
      longitude: Joi.number().required(),
      sortOrder: Joi.number().integer().default(0),
    })
  ).optional(),
  paymentDetailId: Joi.when("paymentMethod", {
    is: Joi.valid("EXISTING_CARD", "SQUARE_SAVED_CARD"),
    then: Joi.number().when("paymentMethod", {
      is: "EXISTING_CARD",
      then: Joi.required(),
      otherwise: Joi.optional(),
    }),
    otherwise: Joi.forbidden(),
  }),
  returnPickupDateTime: Joi.string()
    .regex(dateFormat)
    .message("Invalid return Pickup Date format. " + dateFormatMessage)
    .when("tripType", {
      is: Joi.string().valid(
        "Ride to the airport(round trip)",
        "Ride from the airport(round trip)"
      ),
      then: Joi.required(),
      otherwise: Joi.allow(null),
    }),
  cardDetails: Joi.when("paymentMethod", {
    is: "NEW_CARD",
    then: cardDetailsSchema.required(),
    otherwise: Joi.forbidden(),
  }),
  promoCode: Joi.string().trim().uppercase().max(20).optional(),
  // Auto-apply is the default (omitted/true); false opts out of using wallet
  // credit on this booking entirely.
  useWalletCredit: Joi.boolean().default(true),
})
  .custom((value, helpers) => {
    const { isLegacyPaymentProvider } = require("../../config/paymentConfig.js");
    if (
      !isLegacyPaymentProvider() &&
      value.paymentMethod === "NEW_CARD" &&
      value.cardDetails
    ) {
      return helpers.message(
        "Raw cardDetails are deprecated. Use SQUARE_NEW_CARD with square.sourceId from Square SDK."
      );
    }
    return value;
  })
  .custom((value, helpers) => {
  const id = value.airportId;
  const hasCatalogAirport =
    id !== undefined && id !== null && id !== "" && Number(id) > 0;

  const addr =
    typeof value.airportLocationAddress === "string"
      ? value.airportLocationAddress.trim()
      : "";
  const lat = value.airportLocationLatitude;
  const lng = value.airportLocationLongitude;
  const hasGeoTerminal =
    addr.length > 0 &&
    lat !== undefined &&
    lat !== null &&
    lng !== undefined &&
    lng !== null;

  if (!hasCatalogAirport && !hasGeoTerminal) {
    return helpers.message(
      "Provide either airportId (catalog airport) or airport terminal: airportLocationAddress, airportLocationLatitude, airportLocationLongitude"
    );
  }
  if (hasCatalogAirport && hasGeoTerminal) {
    return helpers.message(
      "Send either airportId or airport location fields (address + coordinates), not both"
    );
  }
  return value;
});

/**
 * User update schema (partial). Payment fields and status fields are intentionally excluded.
 * Note: airport location must still be provided via either airportId or airportLocation* when updating them.
 */
const validateAirportBookUpdate = Joi.object({
  tripType: Joi.string().valid(
    "Ride to the airport(one way)",
    "Ride from the airport(one way)",
    "Ride to the airport(round trip)",
    "Ride from the airport(round trip)"
  ),
  numberOfPassengers: Joi.number().integer().min(1),
  numberOfSuitcases: Joi.number().integer().min(0),
  accommodationAddress: Joi.string(),
  accommodationLongitude: Joi.number(),
  accommodationLatitude: Joi.number(),
  pickupDateTime: Joi.string()
    .regex(dateFormat)
    .message("Invalid pickup Date format. " + dateFormatMessage),
  returnPickupDateTime: Joi.string()
    .regex(dateFormat)
    .message("Invalid return Pickup Date format. " + dateFormatMessage),
  distanceInMiles: Joi.number().precision(2),
  airline: Joi.string().allow(""),
  arrivalFlightNumber: Joi.string().allow(""),
  returnAirline: Joi.string().allow(""),
  returnFlightNumber: Joi.string().allow(""),
  specialInstructions: Joi.string().allow(""),
  carId: Joi.number().integer().allow(null),
  gratuityId: Joi.number().integer().allow(null),
  airportId: Joi.number().integer().positive().allow(null),
  airportLocationAddress: Joi.string().allow("", null),
  airportLocationLatitude: Joi.number().allow(null),
  airportLocationLongitude: Joi.number().allow(null),
  extraOptions: Joi.array().items(extraOptionSchema).min(0),
  pickupPreferenceId: Joi.number().integer().allow(null),
  additionalStopId: Joi.number().integer().allow(null),
  additionalStopOnTheWayDescription: Joi.string().allow(""),
  // Was missing here even though updateAirportBookForUser already has code
  // to destroy/recreate SidePickDetour rows from it — this Joi schema was
  // silently rejecting the field before that code ever ran, so a customer
  // editing their side-detour stops always failed at validation.
  sidePicks: Joi.array().items(
    Joi.object({
      address: Joi.string().required(),
      latitude: Joi.number().required(),
      longitude: Joi.number().required(),
      sortOrder: Joi.number().integer().default(0),
    })
  ).optional(),
  // Present + a real code: apply/replace whatever promo is currently on
  // this booking. Present + "" or null: remove it. Absent entirely: leave
  // whatever's already applied untouched.
  promoCode: Joi.string().trim().uppercase().max(20).allow("", null).optional(),
  // Omitted: leave wallet credit as-is. true: (re)apply. false: remove it
  // from this booking. Same "touched" idiom as promoCode above.
  useWalletCredit: Joi.boolean(),
  bookingFor: Joi.string().valid("Myself", "SomeoneElse"),
  passengerFullName: Joi.string().min(2).max(100),
  passengerEmail: Joi.string().email().max(255),
  passengerCellPhone: Joi.string()
    .pattern(/^[0-9]{10,15}$/)
    .message("Please provide a valid guest phone number."),
  square: Joi.object({
    sourceId: Joi.string().required(),
    verificationToken: Joi.string().allow("", null),
  }).optional(),
  squareCardId: Joi.string().optional(),
  // Which saved card `squareCardId` belongs to — required to switch to a
  // DIFFERENT saved card than whatever is already on the booking (without
  // it, the update would keep resolving the booking's existing card).
  paymentDetailId: Joi.number().integer().optional(),
}).min(1).custom((value, helpers) => {
  // Only enforce the "either airportId OR airportLocation*" rule if the update tries
  // to modify any of the airport fields.
  const touchesAirport =
    Object.prototype.hasOwnProperty.call(value, "airportId") ||
    Object.prototype.hasOwnProperty.call(value, "airportLocationAddress") ||
    Object.prototype.hasOwnProperty.call(value, "airportLocationLatitude") ||
    Object.prototype.hasOwnProperty.call(value, "airportLocationLongitude");
  if (!touchesAirport) return value;

  const id = value.airportId;
  const hasCatalogAirport =
    id !== undefined && id !== null && id !== "" && Number(id) > 0;

  const addr =
    typeof value.airportLocationAddress === "string"
      ? value.airportLocationAddress.trim()
      : "";
  const lat = value.airportLocationLatitude;
  const lng = value.airportLocationLongitude;
  const hasGeoTerminal =
    addr.length > 0 &&
    lat !== undefined &&
    lat !== null &&
    lng !== undefined &&
    lng !== null;

  if (!hasCatalogAirport && !hasGeoTerminal) {
    return helpers.message(
      "To update airport location, provide either airportId or airportLocationAddress + airportLocationLatitude + airportLocationLongitude"
    );
  }
  if (hasCatalogAirport && hasGeoTerminal) {
    return helpers.message(
      "To update airport location, send either airportId or airport location fields (address + coordinates), not both"
    );
  }
  return value;
});

module.exports = {
  AirportBook,
  validateAirportBook,
  validateAirportBookUpdate,
};

