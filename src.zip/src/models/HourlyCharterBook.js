// const { DataTypes } = require("sequelize");
// const Joi = require("joi");
// const { sequelize } = require("../config/database.js");
// const { Car } = require("./Car.js");
// const { User } = require("./user/User.js");
// const HourlyCharterBookExtraOptions = require("./HourlyCharterBookExtraOption.js");
// const { ExtraOption } = require("./ExtraOption.js");
// const { Gratuity } = require("./Gratuity.js");
// const { PaymentDetail } = require("./PaymentDetail.js");

// const {
//   extraOptionSchema,
//   dateFormat,
//   dateFormatMessage,
//   testCards,
//   creditCardNumberMessage,
//   expirationDateMessage,
//   securityCodeMessage,
// } = require("./../utils/validationUtils");

// const HourlyCharterBook = sequelize.define(
//   "HourlyCharterBook",
//   {
//     hourlyCharterBookId: {
//       type: DataTypes.BIGINT,
//       primaryKey: true,
//       autoIncrement: true,
//       allowNull: false,
//     },
//     confirmationNumber: {
//       type: DataTypes.STRING,
//       allowNull: false,
//       unique: true,
//     },
//     pickupPhysicalAddress: {
//       type: DataTypes.STRING,
//       allowNull: false,
//     },
//     pickupLongitude: {
//       type: DataTypes.FLOAT,
//       allowNull: false,
//     },
//     pickupLatitude: {
//       type: DataTypes.FLOAT,
//       allowNull: false,
//     },

//     dropoffPhysicalAddress: {
//       type: DataTypes.STRING,
//       allowNull: false,
//     },
//     dropoffLongitude: {
//       type: DataTypes.FLOAT,
//       allowNull: false,
//     },
//     dropoffLatitude: {
//       type: DataTypes.FLOAT,
//       allowNull: false,
//     },

//     pickupDateTime: {
//       type: DataTypes.DATE,
//       set(value) {
//         const date = new Date(value);
//         date.setSeconds(0);
//         this.setDataValue("pickupDateTime", date);
//       },
//     },

//     selectedHours: {
//       type: DataTypes.INTEGER,
//       allowNull: false,
//     },

//     occasion: {
//       type: DataTypes.STRING,
//       allowNull: false,
//     },

//     specialInstructions: {
//       type: DataTypes.TEXT,
//     },

//     isGuestBooking: {
//       type: DataTypes.BOOLEAN,
//       defaultValue: false,
//     },
//     bookingFor: {
//       type: DataTypes.ENUM("Myself", "SomeoneElse"),
//       allowNull: false,
//       defaultValue: "Myself",
//     },
//     passengerFullName: {
//       type: DataTypes.STRING,
//       allowNull: false,
//       validate: {
//         len: [2, 100],
//       },
//     },
//     paymentMethod: {
//       type: DataTypes.ENUM("PRIMARY_CARD", "EXISTING_CARD", "NEW_CARD"),
//       allowNull: false,
//     },
//     passengerCellPhone: {
//       type: DataTypes.STRING,
//       allowNull: false,
//       validate: {
//         is: /^[0-9]{10,15}$/,
//       },
//     },
//     passengerEmail: {
//       type: DataTypes.STRING,
//       allowNull: false,
//       validate: {
//         isEmail: true,
//         len: [1, 255],
//       },
//     },

//     numberOfPassengers: {
//       type: DataTypes.INTEGER,
//     },
//     numberOfSuitcases: {
//       type: DataTypes.INTEGER,
//     },

//     totalTripFeeInDollars: {
//       type: DataTypes.DECIMAL(10, 2),
//       validate: {
//         min: {
//           args: [1],
//         },
//       },
//     },
//     paymentStatus: {
//       type: DataTypes.ENUM(
//         "NOT_PAID",
//         "AWAITING_PAYMENT",
//         "PARTIALLY_PAID",
//         "PAID",
//         "PENDING_REFUND",
//         "REFUNDED",
//         "CANCELLED"
//       ),
//       defaultValue: "NOT_PAID",
//     },

//     bookingStatus: {
//       type: DataTypes.ENUM(
//         "PENDING_APPROVAL",
//         "UNDER_REVIEW",
//         "ACCEPTED",
//         "REJECTED",
//         "CANCELLED",
//         "AWAITING_PICKUP",
//         "PICKUP_COMPLETED",
//         "EN_ROUTE",
//         "AWAITING_RETURN_PICKUP",
//         "RETURN_PICKUP_COMPLETED",
//         "OVERDUE",
//         "DISPUTED",
//         "COMPLETED"
//       ),
//       defaultValue: "PENDING_APPROVAL",
//     },
//   },
//   {
//     sequelize,
//     modelName: "HourlyCharterBook",
//     tableName: "hourly_charter_books",
//     paranoid: true,
//   }
// );

// // Define association with PaymentDetail model
// HourlyCharterBook.belongsTo(PaymentDetail, { 
//   foreignKey: "paymentDetailId" ,
//   targetKey: "paymentDetailId"
// });

// // Define association with User model
// HourlyCharterBook.belongsTo(User, { foreignKey: "userId" });

// // Define association with Car model
// HourlyCharterBook.belongsTo(Car, { foreignKey: "carId" });

// // Define association with Gratuity model
// HourlyCharterBook.belongsTo(Gratuity, { foreignKey: "gratuityId" });

// // Associate HourlyCharterBook with ExtraOption through HourlyCharterBookExtraOptions
// HourlyCharterBook.belongsToMany(ExtraOption, {
//   through: HourlyCharterBookExtraOptions,
//   foreignKey: "hourlyCharterBookId",
//   otherKey: "extraOptionId",
//   uniqueKey: "book_extra_options_unique",
// });

// ExtraOption.belongsToMany(HourlyCharterBook, {
//   through: HourlyCharterBookExtraOptions,
//   foreignKey: "extraOptionId",
//   otherKey: "hourlyCharterBookId",
//   uniqueKey: "book_extra_options_unique",
// });

// const cardDetailsSchema = Joi.object({
//   creditCardNumber: Joi.string()
//     .creditCard()
//     .required()
//     .messages({
//       'string.creditCard': 'Invalid credit card number',
//       'any.required': 'Credit card number is required'
//     }),
//   expirationDate: Joi.string()
//     .pattern(/^(0[1-9]|1[0-2])\/([0-9]{2})$/)
//     .required()
//     .custom((value, helpers) => {
//       const [month, year] = value.split('/');
//       const currentYear = new Date().getFullYear() % 100;
//       const currentMonth = new Date().getMonth() + 1;
      
//       // Convert YY to full year (2000 + YY)
//       const fullYear = 2000 + parseInt(year, 10);
      
//       // Check if expiration date is in the future
//       if (
//         fullYear < new Date().getFullYear() || 
//         (fullYear === new Date().getFullYear() && parseInt(month, 10) < currentMonth)
//       ) {
//         return helpers.error('date.expired');
//       }
      
//       return value;
//     })
//     .messages({
//       'string.pattern.base': 'Expiration date must be in MM/YY format',
//       'date.expired': 'Card has expired',
//       'any.required': 'Expiration date is required'
//     }),
//   securityCode: Joi.string()
//     .pattern(/^[0-9]{3,4}$/)
//     .required()
//     .messages({
//       'string.pattern.base': 'Security code must be 3 or 4 digits',
//       'any.required': 'Security code is required'
//     }),
//   zipCode: Joi.string()
//     .pattern(/^[0-9]{5}(?:-[0-9]{4})?$/)
//     .required()
//     .messages({
//       'string.pattern.base': 'Invalid ZIP code format',
//       'any.required': 'ZIP code is required'
//     }),
//   cardOwnerName: Joi.string()
//     .min(2)
//     .max(100)
//     .pattern(/^[a-zA-Z\s]+$/)
//     .required()
//     .messages({
//       'string.min': 'Cardholder name must be at least 2 characters',
//       'string.max': 'Cardholder name must be less than 100 characters',
//       'string.pattern.base': 'Cardholder name can only contain letters and spaces',
//       'any.required': 'Cardholder name is required'
//     })
// });
// function validateHourlyCharterBook(hourlyCharterBook) {
//   const schema = Joi.object({
//     pickupPhysicalAddress: Joi.string().required(),
//     pickupLongitude: Joi.number().required(),
//     pickupLatitude: Joi.number().required(),
//     dropoffPhysicalAddress: Joi.string().required(),
//     dropoffLongitude: Joi.number().required(),
//     dropoffLatitude: Joi.number().required(),
//     selectedHours: Joi.number().integer().min(1).max(24).required(),
//     occasion: Joi.string().min(1).max(100).required(),
//     numberOfPassengers: Joi.number().integer().min(1).required(),
//     numberOfSuitcases: Joi.number().integer().min(0).default(0),
//     carId: Joi.number().integer().required(),
//     gratuityId: Joi.number().integer().required(),
//     extraOptions: Joi.array().items(extraOptionSchema).min(1),
//     pickupDateTime: Joi.string()
//       .regex(dateFormat)
//       .message("Invalid pickup Date format. " + dateFormatMessage)
//       .required(),
//     specialInstructions: Joi.string().allow(""),

//     isGuestBooking: Joi.boolean().default(false).required(),
//     bookingFor: Joi.string().valid("Myself", "SomeoneElse").required(),
//     passengerFullName: Joi.string().min(2).max(100).required(),
//     paymentMethod: Joi.string()
//       .valid("PRIMARY_CARD", "EXISTING_CARD", "NEW_CARD")
//       .default("NEW_CARD"),
//     passengerEmail: Joi.string().email().max(255).required(),
//     passengerCellPhone: Joi.string()
//       .pattern(/^[0-9]{10,15}$/)
//       .message("Please provide a valid guest phone number.")
//       .required(),

//     //Payment info
//     cardDetails: Joi.when('paymentMethod', {
//       is: 'NEW_CARD',
//       then: cardDetailsSchema.required(),
//       otherwise: Joi.forbidden()
//     }),
//     paymentDetailId: Joi.when('paymentMethod', {
//       is: 'EXISTING_CARD',
//       then: Joi.number().required(),
//       otherwise: Joi.forbidden()
//     })
//   });

//   return schema.validate(hourlyCharterBook);
// }

// module.exports = { validateHourlyCharterBook, HourlyCharterBook };




const { DataTypes } = require("sequelize");
const Joi = require("joi");
const { sequelize } = require("../config/database.js");
const { Car } = require("./Car.js");
const { User } = require("./user/User.js");
const HourlyCharterBookExtraOptions = require("./HourlyCharterBookExtraOption.js");
const { ExtraOption } = require("./ExtraOption.js");
const { Gratuity } = require("./Gratuity.js");
const { PaymentDetail } = require("./PaymentDetail.js");

const {
  extraOptionSchema,
  dateFormat,
  dateFormatMessage,
  testCards,
  creditCardNumberMessage,
  expirationDateMessage,
  securityCodeMessage,
} = require("./../utils/validationUtils");

const HourlyCharterBook = sequelize.define(
  "HourlyCharterBook",
  {
    hourlyCharterBookId: {
      type: DataTypes.BIGINT,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },
    confirmationNumber: {
      type: DataTypes.STRING,
      allowNull: false,
      // Named to match the existing DB index so alter-sync doesn't generate
      // a fresh duplicate index on every restart (see PaymentTransaction.js
      // idempotencyKey for what that leads to).
      unique: "confirmationNumber",
    },
    pickupPhysicalAddress: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    pickupLongitude: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
    pickupLatitude: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },

    dropoffPhysicalAddress: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    dropoffLongitude: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
    dropoffLatitude: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },

    pickupDateTime: {
      type: DataTypes.DATE,
      set(value) {
        const date = new Date(value);
        date.setSeconds(0);
        this.setDataValue("pickupDateTime", date);
      },
    },

    selectedHours: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },

    // ─── Live billing mode ────────────────────────────────────────────────────
    // PRE_BOOKED: fixed charge = pricePerHour × selectedHours (default)
    // LIVE:       pre-auth includes a buffer; actual charge calculated at trip end
    billingMode: {
      type: DataTypes.ENUM("PRE_BOOKED", "LIVE"),
      allowNull: false,
      defaultValue: "PRE_BOOKED",
    },
    // Extra hours included in the Square pre-authorization for LIVE bookings
    preAuthBufferHours: {
      type: DataTypes.INTEGER,
      defaultValue: 2,
    },
    // Set by admin/driver when the trip clock starts (LIVE mode)
    actualStartTime: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    // Set by admin/driver when the trip ends (LIVE mode)
    actualEndTime: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    // Computed: decimal hours between actualStartTime and actualEndTime
    actualHoursUsed: {
      type: DataTypes.DECIMAL(6, 2),
      allowNull: true,
    },
    // max(0, actualHoursUsed - selectedHours)
    overtimeHours: {
      type: DataTypes.DECIMAL(6, 2),
      allowNull: true,
      defaultValue: 0,
    },
    // Legacy field, retained for historical records only — no longer applied.
    // Extra time beyond the booked hours is now billed at the plain per-hour
    // rate (no overtime premium); see calculateExtraTimeFare().
    overtimeRateMultiplier: {
      type: DataTypes.DECIMAL(4, 2),
      defaultValue: 1.5,
    },
    // Overtime charge = pricePerHour × overtimeHours (no multiplier)
    overtimeAmountInDollars: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true,
      defaultValue: 0,
    },

    // ─── Flexibility features ─────────────────────────────────────────────────
    // Feature 1 — Extend PRE_BOOKED with live meter after booked hours expire
    // Timestamp when the live extension was activated
    liveExtensionStartedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    // Original fixed fare snapshot (preserved so extension fare is additive)
    liveExtensionBaseFare: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true,
    },
    // Computed extension fare set at end-trip
    liveExtensionFareInDollars: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true,
      defaultValue: 0,
    },
    // Feature 2 — PRE_BOOKED booking converted to LIVE at start by driver/admin
    convertedToLiveAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    // The driver (or admin) who actually started this trip — used to scope a
    // driver's personal trip history to only the trips they served, instead
    // of every driver's history (there's no fixed driver assignment on a
    // booking; any driver/admin may pick up any accepted booking).
    servingDriverId: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    // ─────────────────────────────────────────────────────────────────────────

    occasion: {
      type: DataTypes.STRING,
      allowNull: false,
    },

    specialInstructions: {
      type: DataTypes.TEXT,
    },

    isGuestBooking: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    bookingFor: {
      type: DataTypes.ENUM("Myself", "SomeoneElse"),
      allowNull: false,
      defaultValue: "Myself",
    },
    passengerFullName: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        len: [2, 100],
      },
    },
    paymentMethod: {
      type: DataTypes.STRING(32),
      allowNull: false,
    },
    passengerCellPhone: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        is: /^[0-9]{10,15}$/,
      },
    },
    passengerEmail: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        isEmail: true,
        len: [1, 255],
      },
    },

    numberOfPassengers: {
      type: DataTypes.INTEGER,
    },
    numberOfSuitcases: {
      type: DataTypes.INTEGER,
    },

    totalTripFeeInDollars: {
      type: DataTypes.DECIMAL(10, 2),
      validate: {
        min: {
          args: [1],
        },
      },
    },
    // Admin manual discount only (see applyDiscountToHourlyCharterBook). Kept
    // separate from promoDiscountAmountInDollars so one can never silently
    // overwrite the other — the two are always additive against a freshly
    // recomputed base fare.
    discountAmountInDollars: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true,
      defaultValue: 0.00,
      validate: {
        min: 0,
      },
    },
    // Promo-code discount only, frozen at booking-creation time.
    promoDiscountAmountInDollars: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true,
      defaultValue: 0.00,
      validate: {
        min: 0,
      },
    },
    // Wallet credit applied to this booking (see walletService.js) — a third
    // discount bucket, independent of and additive with the two above.
    walletCreditAppliedInDollars: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true,
      defaultValue: 0.00,
      validate: {
        min: 0,
      },
    },
    hasDiscountApplied: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    paymentStatus: {
      type: DataTypes.ENUM(
        "NOT_PAID",
        "AWAITING_PAYMENT",
        "AUTHORIZED",
        "PARTIALLY_PAID",
        "PAID",
        "PENDING_REFUND",
        "REFUNDED",
        "CANCELLED",
        "DISCOUNT_APPLIED"
      ),
      defaultValue: "NOT_PAID",
    },

    bookingStatus: {
      type: DataTypes.ENUM(
        "PENDING_APPROVAL",
        "UNDER_REVIEW",
        "ACCEPTED",
        "REJECTED",
        "CANCELLED",
        "AWAITING_PICKUP",
        "PICKUP_COMPLETED",
        "EN_ROUTE",
        "AWAITING_RETURN_PICKUP",
        "RETURN_PICKUP_COMPLETED",
        "OVERDUE",
        "DISPUTED",
        "COMPLETED"
      ),
      defaultValue: "PENDING_APPROVAL",
    },
  },
  {
    sequelize,
    modelName: "HourlyCharterBook",
    tableName: "hourly_charter_books",
    paranoid: true,
  }
);

// Define association with PaymentDetail model
HourlyCharterBook.belongsTo(PaymentDetail, { 
  foreignKey: "paymentDetailId" ,
  targetKey: "paymentDetailId"
});

// Define association with User model
HourlyCharterBook.belongsTo(User, { foreignKey: "userId" });

// The driver/admin who started (is serving) this trip
HourlyCharterBook.belongsTo(User, {
  foreignKey: "servingDriverId",
  as: "ServingDriver",
  constraints: false,
});

// Define association with Car model
HourlyCharterBook.belongsTo(Car, { foreignKey: "carId" });

// Define association with Gratuity model
HourlyCharterBook.belongsTo(Gratuity, { foreignKey: "gratuityId" });

// Associate HourlyCharterBook with ExtraOption through HourlyCharterBookExtraOptions
HourlyCharterBook.belongsToMany(ExtraOption, {
  through: HourlyCharterBookExtraOptions,
  foreignKey: "hourlyCharterBookId",
  otherKey: "extraOptionId",
  uniqueKey: "book_extra_options_unique",
});

ExtraOption.belongsToMany(HourlyCharterBook, {
  through: HourlyCharterBookExtraOptions,
  foreignKey: "extraOptionId",
  otherKey: "hourlyCharterBookId",
  uniqueKey: "book_extra_options_unique",
});

const cardDetailsSchema = Joi.object({
  creditCardNumber: Joi.string()
    .creditCard()
    .required()
    .messages({
      'string.creditCard': 'Invalid credit card number',
      'any.required': 'Credit card number is required'
    }),
  expirationDate: Joi.string()
    .pattern(/^(0[1-9]|1[0-2])\/([0-9]{2})$/)
    .required()
    .custom((value, helpers) => {
      const [month, year] = value.split('/');
      const currentYear = new Date().getFullYear() % 100;
      const currentMonth = new Date().getMonth() + 1;
      
      // Convert YY to full year (2000 + YY)
      const fullYear = 2000 + parseInt(year, 10);
      
      // Check if expiration date is in the future
      if (
        fullYear < new Date().getFullYear() || 
        (fullYear === new Date().getFullYear() && parseInt(month, 10) < currentMonth)
      ) {
        return helpers.error('date.expired');
      }
      
      return value;
    })
    .messages({
      'string.pattern.base': 'Expiration date must be in MM/YY format',
      'date.expired': 'Card has expired',
      'any.required': 'Expiration date is required'
    }),
  securityCode: Joi.string()
    .pattern(/^[0-9]{3,4}$/)
    .required()
    .messages({
      'string.pattern.base': 'Security code must be 3 or 4 digits',
      'any.required': 'Security code is required'
    }),
  zipCode: Joi.string()
    .pattern(/^[0-9]{5}(?:-[0-9]{4})?$/)
    .required()
    .messages({
      'string.pattern.base': 'Invalid ZIP code format',
      'any.required': 'ZIP code is required'
    }),
  cardOwnerName: Joi.string()
    .min(2)
    .max(100)
    .pattern(/^[a-zA-Z\s]+$/)
    .required()
    .messages({
      'string.min': 'Cardholder name must be at least 2 characters',
      'string.max': 'Cardholder name must be less than 100 characters',
      'string.pattern.base': 'Cardholder name can only contain letters and spaces',
      'any.required': 'Cardholder name is required'
    })
});

const validateHourlyCharterBook = Joi.object({
  pickupPhysicalAddress: Joi.string().required(),
  pickupLongitude: Joi.number().required(),
  pickupLatitude: Joi.number().required(),
  dropoffPhysicalAddress: Joi.string().required(),
  dropoffLongitude: Joi.number().required(),
  dropoffLatitude: Joi.number().required(),
  selectedHours: Joi.number().integer().min(1).max(24).required(),
  billingMode: Joi.string().valid('PRE_BOOKED', 'LIVE').default('PRE_BOOKED').optional(),
  occasion: Joi.string().min(1).max(100).required(),
  numberOfPassengers: Joi.number().integer().min(1).required(),
  numberOfSuitcases: Joi.number().integer().min(0).default(0),
  carId: Joi.number().integer().required(),
  gratuityId: Joi.number().integer().required(),
  extraOptions: Joi.array().items(extraOptionSchema).min(1),
  pickupDateTime: Joi.string()
    .regex(dateFormat)
    .message("Invalid pickup Date format. " + dateFormatMessage)
    .required(),
  specialInstructions: Joi.string().allow(""),

  isGuestBooking: Joi.boolean().default(false).required(),
  bookingFor: Joi.string().valid("Myself", "SomeoneElse").required(),
  passengerFullName: Joi.string().min(2).max(100).required(),
  paymentMethod: Joi.string()
    .valid(
      "PRIMARY_CARD",
      "EXISTING_CARD",
      "NEW_CARD",
      "SQUARE_NEW_CARD",
      "SQUARE_SAVED_CARD"
    )
    .default("SQUARE_NEW_CARD"),
  square: Joi.when("paymentMethod", {
    is: "SQUARE_NEW_CARD",
    then: Joi.object({
      sourceId: Joi.string().required(),
      verificationToken: Joi.string().allow("", null),
    }).required(),
    otherwise: Joi.forbidden(),
  }),
  squareCardId: Joi.when("paymentMethod", {
    is: "SQUARE_SAVED_CARD",
    then: Joi.string().optional(),
    otherwise: Joi.forbidden(),
  }),
  passengerEmail: Joi.string().email().max(255).required(),
  passengerCellPhone: Joi.string()
    .pattern(/^[0-9]{10,15}$/)
    .message("Please provide a valid guest phone number.")
    .required(),

  cardDetails: Joi.when("paymentMethod", {
    is: "NEW_CARD",
    then: cardDetailsSchema.required(),
    otherwise: Joi.forbidden(),
  }),
  paymentDetailId: Joi.when("paymentMethod", {
    is: Joi.valid("EXISTING_CARD", "SQUARE_SAVED_CARD"),
    then: Joi.number().when("paymentMethod", {
      is: "EXISTING_CARD",
      then: Joi.required(),
      otherwise: Joi.optional(),
    }),
    otherwise: Joi.forbidden(),
  }),
  promoCode: Joi.string().trim().uppercase().max(20).optional(),
  // Auto-apply is the default (omitted/true); false opts out of using wallet
  // credit on this booking entirely.
  useWalletCredit: Joi.boolean().default(true),
})
  .custom((value, helpers) => {
    const { isLegacyPaymentProvider } = require("../config/paymentConfig.js");
    if (
      !isLegacyPaymentProvider() &&
      value.paymentMethod === "NEW_CARD" &&
      value.cardDetails
    ) {
      return helpers.message(
        "Raw cardDetails are deprecated. Use SQUARE_NEW_CARD with square.sourceId."
      );
    }
    return value;
  });

/**
 * User update schema (partial). Payment fields and status fields are intentionally excluded.
 */
const validateHourlyCharterBookUpdate = Joi.object({
  pickupPhysicalAddress: Joi.string(),
  pickupLongitude: Joi.number(),
  pickupLatitude: Joi.number(),
  dropoffPhysicalAddress: Joi.string(),
  dropoffLongitude: Joi.number(),
  dropoffLatitude: Joi.number(),
  selectedHours: Joi.number().integer().min(1).max(24),
  occasion: Joi.string().min(1).max(100),
  numberOfPassengers: Joi.number().integer().min(1),
  numberOfSuitcases: Joi.number().integer().min(0),
  carId: Joi.number().integer().allow(null),
  gratuityId: Joi.number().integer().allow(null),
  extraOptions: Joi.array().items(extraOptionSchema).min(0),
  pickupDateTime: Joi.string()
    .regex(dateFormat)
    .message("Invalid pickup Date format. " + dateFormatMessage),
  specialInstructions: Joi.string().allow(""),
  // Present + a real code: apply/replace whatever promo is currently on
  // this booking. Present + "" or null: remove it. Absent entirely: leave
  // whatever's already applied untouched.
  promoCode: Joi.string().trim().uppercase().max(20).allow("", null).optional(),
  // Omitted: leave wallet credit as-is. true: (re)apply. false: remove it
  // from this booking. Same "touched" idiom as promoCode above.
  useWalletCredit: Joi.boolean(),
  bookingFor: Joi.string().valid("Myself", "SomeoneElse"),
  passengerFullName: Joi.string().min(2).max(100),
  passengerEmail: Joi.string().email().max(255),
  passengerCellPhone: Joi.string()
    .pattern(/^[0-9]{10,15}$/)
    .message("Please provide a valid guest phone number."),
  square: Joi.object({
    sourceId: Joi.string().required(),
    verificationToken: Joi.string().allow("", null),
  }).optional(),
  squareCardId: Joi.string().optional(),
  // Which saved card `squareCardId` belongs to — required to switch to a
  // DIFFERENT saved card than whatever is already on the booking (without
  // it, the update would keep resolving the booking's existing card).
  paymentDetailId: Joi.number().integer().optional(),
}).min(1);

module.exports = {
  validateHourlyCharterBook,
  validateHourlyCharterBookUpdate,
  HourlyCharterBook,
};
