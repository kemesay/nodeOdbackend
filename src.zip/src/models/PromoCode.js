const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/database.js");
const Joi = require("joi");
const { User } = require("./user/User.js");

const BOOKING_TYPES = ["Point to point", "Hourly Charter", "Airport Service"];

/**
 * A redeemable code. Three flavors share this one table (`type`):
 *  - "public"   admin-created campaign code (e.g. ODACAR10), shared by many riders.
 *  - "referral" auto-generated per user (FirstName + short hash of userId), given to
 *               friends the owner invites; discounts the *referred* rider's first ride.
 *  - "reward"   auto-minted single-use code credited to a referrer once their
 *               referral's first ride is completed — this is how a "wallet credit"
 *               is represented without a wallet system existing yet.
 */
const PromoCode = sequelize.define(
  "PromoCode",
  {
    promoCodeId: {
      type: DataTypes.BIGINT,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },
    code: {
      type: DataTypes.STRING(20),
      allowNull: false,
      unique: true,
      // Model-level backstop for the uppercase-canonical rule (see
      // promoCodeSchema below for the Joi-layer version of the same
      // normalization) — guarantees the invariant holds even for a write
      // path that bypasses Joi entirely (e.g. a future maintenance script
      // or console/REPL call), since every assignment to `code`, anywhere,
      // funnels through this setter before it ever reaches the database.
      set(value) {
        this.setDataValue("code", String(value ?? "").trim().toUpperCase());
      },
    },
    type: {
      type: DataTypes.ENUM("public", "referral", "reward"),
      allowNull: false,
    },
    ownerUserId: {
      // Who this code "belongs to" — the referrer for referral/reward codes,
      // null for public campaign codes.
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    discountType: {
      type: DataTypes.ENUM("percent", "flat"),
      allowNull: false,
      defaultValue: "percent",
    },
    discountValue: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
      validate: { min: 0.01 },
    },
    maxDiscountAmount: {
      // Cap for percent discounts (ignored for flat). Null = uncapped.
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true,
    },
    minFareAmount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true,
    },
    applicableBookingTypes: {
      // JSON array of BOOKING_TYPES values, or null = applies to all.
      type: DataTypes.JSON,
      allowNull: true,
    },
    firstRideOnly: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    maxTotalRedemptions: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    maxRedemptionsPerUser: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 1,
    },
    // Legacy rolling-window column — superseded by startsAt-scoped
    // maxRedemptionsPerPeriod below (kept as a real column, no longer read
    // or accepted anywhere).
    periodDays: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    // Cap on top of (not instead of) maxRedemptionsPerUser, scoped to this
    // code's OWN active window (startsAt through now) rather than a fixed
    // trailing number of days — e.g. maxRedemptionsPerPeriod=5 means "5 uses
    // per person since this code's Start Date". Since an admin can move
    // startsAt forward at any time to relaunch this code for a new occasion,
    // that naturally gives every customer a fresh allowance for the new
    // period without touching the permanent, all-time maxRedemptionsPerUser
    // cap. Falls back to "since this code has ever existed" when startsAt is
    // unset.
    maxRedemptionsPerPeriod: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    campaignSource: {
      // e.g. "instagram_aug26" — public/social codes only, for channel attribution.
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
    startsAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    expiresAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    sequelize,
    modelName: "PromoCode",
    tableName: "promo_codes",
  }
);

const PromoCodeRedemption = sequelize.define(
  "PromoCodeRedemption",
  {
    promoCodeRedemptionId: {
      type: DataTypes.BIGINT,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },
    promoCodeId: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    redeemedByUserId: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    // Guest identity proxy — a guest has no userId to rate-limit against, so
    // per-user caps fall back to matching on whatever contact info they gave
    // at booking time. Nullable: only populated when redeemedByUserId isn't.
    guestEmail: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    guestPhone: {
      type: DataTypes.STRING(20),
      allowNull: true,
    },
    bookingId: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    bookingType: {
      type: DataTypes.ENUM(...BOOKING_TYPES),
      allowNull: false,
    },
    discountApplied: {
      // Frozen at redemption time — later changes to the promo code must not
      // retroactively change what a past booking actually charged.
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
    },
    status: {
      type: DataTypes.ENUM("confirmed", "reversed"),
      allowNull: false,
      defaultValue: "confirmed",
    },
  },
  {
    sequelize,
    modelName: "PromoCodeRedemption",
    tableName: "promo_code_redemptions",
  }
);

const ReferralReward = sequelize.define(
  "ReferralReward",
  {
    referralRewardId: {
      type: DataTypes.BIGINT,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },
    referrerUserId: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    // Nullable — a referred friend who books as a guest (never registers)
    // still earns the referrer a reward; referredGuestEmail/Phone identify
    // them instead in that case.
    referredUserId: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    referredGuestEmail: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    referredGuestPhone: {
      type: DataTypes.STRING(20),
      allowNull: true,
    },
    promoCodeId: {
      // The referral code that was redeemed to create this reward.
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    triggeringBookingId: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    triggeringBookingType: {
      type: DataTypes.ENUM(...BOOKING_TYPES),
      allowNull: true,
    },
    // % off the referrer's next ride — the same figure as
    // ReferralSettings.referralDiscountPercent at the moment this reward was
    // opened (see redeemPromoCode), frozen here so a later settings change
    // never retroactively changes an already-pending reward.
    rewardPercent: {
      type: DataTypes.DECIMAL(5, 2),
      allowNull: false,
    },
    rewardCodeId: {
      // The auto-minted "reward" PromoCode handed to the referrer once
      // credited — no longer set for new rows (the referrer gets a wallet
      // credit lot instead, see creditReferralRewardIfCompleted), kept
      // nullable for historical rows minted before the wallet existed.
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    // The actual dollar amount credited to the referrer's wallet (set
    // alongside rewardStatus: "credited") — rewardPercent above is frozen at
    // the moment the referral is opened, but the dollar amount can only be
    // known once the referred ride's final paid total is known, at crediting
    // time.
    creditedAmount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true,
    },
    rewardStatus: {
      // "reversed": the wallet credit lot this reward created was clawed
      // back (in full or in its still-unspent part) because the triggering
      // booking was later refunded/cancelled — see
      // walletService.reverseWalletCreditForReferredBooking.
      type: DataTypes.ENUM("pending", "credited", "denied", "reversed"),
      allowNull: false,
      defaultValue: "pending",
    },
    creditedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    sequelize,
    modelName: "ReferralReward",
    tableName: "referral_rewards",
  }
);

PromoCode.hasMany(PromoCodeRedemption, { foreignKey: "promoCodeId" });
PromoCodeRedemption.belongsTo(PromoCode, { foreignKey: "promoCodeId" });

PromoCode.belongsTo(User, { foreignKey: "ownerUserId", as: "owner" });
PromoCodeRedemption.belongsTo(User, { foreignKey: "redeemedByUserId", as: "redeemedBy" });

ReferralReward.belongsTo(PromoCode, { foreignKey: "promoCodeId" });
ReferralReward.belongsTo(User, { foreignKey: "referrerUserId", as: "referrer" });
ReferralReward.belongsTo(User, { foreignKey: "referredUserId", as: "referred" });

// Uppercase is the one canonical case for EVERY code — public or
// auto-generated referral/reward alike — normalized explicitly here in
// application code rather than relying on the database's collation being
// case-insensitive. That collation assumption held on production MySQL
// (*_ci) but does NOT hold on a local Postgres dev database, which is
// case-sensitive by default — the exact gap that let an admin-typed public
// code (stored as-entered, e.g. "OdaCar") silently fail to match a
// customer's differently-cased input outside of production. Uppercase
// (not lowercase) was chosen as the canonical case because every promo-code
// text field on the website and app already forces uppercase as the
// customer types, and industry convention displays codes in caps (e.g.
// "SAVE20"). See scripts/uppercase-existing-promo-codes.js for the one-time
// backfill of codes stored before this change.
const promoCodeSchema = () =>
  Joi.string()
    .trim()
    .uppercase()
    .pattern(/^[a-zA-Z0-9]{4,20}$/)
    .messages({
      "string.pattern.base": "Promo code must be 4-20 letters/numbers, no spaces or symbols.",
    });

/** Admin creating a public/social-media campaign code. */
const validateCreatePromoCode = Joi.object({
  code: promoCodeSchema().required(),
  discountType: Joi.string().valid("percent", "flat").default("percent"),
  discountValue: Joi.number().min(0.01).required(),
  // A percent discount is never capped — always the full percentage of the
  // fare. maxDiscountAmount stays a real column on the table (in case a cap
  // is ever wanted again for some future code), but it's deliberately not
  // accepted here since nothing in the discount calculation reads it.
  // minFareAmount is likewise a real column but no longer accepted here —
  // every public code applies to any fare amount now.
  applicableBookingTypes: Joi.array().items(Joi.string().valid(...BOOKING_TYPES)).allow(null),
  firstRideOnly: Joi.boolean().default(false),
  maxTotalRedemptions: Joi.number().integer().min(1).allow(null),
  maxRedemptionsPerUser: Joi.number().integer().min(1).default(1),
  // On top of (not instead of) maxRedemptionsPerUser — scoped to this code's
  // own Start Date rather than a fixed trailing window (see the model
  // comment on maxRedemptionsPerPeriod). periodDays is a real column too,
  // but stays unaccepted — this field no longer needs a paired day count.
  maxRedemptionsPerPeriod: Joi.number().integer().min(1).allow(null),
  campaignSource: Joi.string().max(50).allow("", null),
  isActive: Joi.boolean().default(true),
  startsAt: Joi.date().allow(null),
  expiresAt: Joi.date().allow(null),
});

/**
 * Admin editing an EXISTING public code's terms — same shape as create,
 * minus `code` itself (never renamed in place: a friend link or shared
 * code text already pointing at the old string would silently break) and
 * with everything optional so a partial PATCH only touches what's sent.
 */
const validateUpdatePromoCode = Joi.object({
  discountType: Joi.string().valid("percent", "flat"),
  discountValue: Joi.number().min(0.01),
  applicableBookingTypes: Joi.array().items(Joi.string().valid(...BOOKING_TYPES)).allow(null),
  firstRideOnly: Joi.boolean(),
  maxTotalRedemptions: Joi.number().integer().min(1).allow(null),
  maxRedemptionsPerUser: Joi.number().integer().min(1),
  maxRedemptionsPerPeriod: Joi.number().integer().min(1).allow(null),
  campaignSource: Joi.string().max(50).allow("", null),
  isActive: Joi.boolean(),
  startsAt: Joi.date().allow(null),
  expiresAt: Joi.date().allow(null),
}).min(1);

/** Applying a code inline as part of a booking payload (booking services pick this out). */
const validateApplyPromoCode = Joi.object({
  code: promoCodeSchema().required(),
});

/** Standalone `/promo-codes/validate` preview — needs the fare context to compute a discount. */
const validatePromoCodePreview = Joi.object({
  code: promoCodeSchema().required(),
  bookingType: Joi.string().valid(...BOOKING_TYPES).required(),
  fareAmount: Joi.number().min(0.01).required(),
});

module.exports = {
  PromoCode,
  PromoCodeRedemption,
  ReferralReward,
  BOOKING_TYPES,
  validateCreatePromoCode,
  validateUpdatePromoCode,
  validateApplyPromoCode,
  validatePromoCodePreview,
};
