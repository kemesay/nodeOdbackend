// const {
//   createHourlyCharterBook,
//   updateHourlyCharterBook,
//   getHourlyCharterBooks,
//   getHourlyCharterBookById,
//   deleteHourlyCharterBook,
//   updateBookingStatus,
//   updatePaymentStatus,
// } = require("../services/hourlyCharter/hourlyCharterBookService.js");

// const authenticateToken = require("../utils/getUserFromToken.js");

// const { successResponse } = require("../utils/responseUtil.js");

// async function createHourlyCharterBookController(req, res, _next) {
//   const tokenHeader = req.header("Authorization");
//   const { paymentMethod, isGuestBooking } = req.body;

//   // Check if payment method requires authentication
//   if ((paymentMethod === 'PRIMARY_CARD' || paymentMethod === 'EXISTING_CARD')) {
//     if (!tokenHeader) {
//       return res.status(401).json({ 
//         error: "Authentication required for using saved payment methods" 
//       });
//     }

//     try {
//       const user = await authenticateToken(tokenHeader);
//       req.body.userId = user.userId;
//     } catch (error) {
//       return res.status(401).json({ 
//         error: "Invalid authentication token" 
//       });
//     }
//   } else if (!isGuestBooking && tokenHeader) {
//     // If user is logged in but using NEW_CARD, still attach userId
//     try {
//       const user = await authenticateToken(tokenHeader);
//       req.body.userId = user.userId;
//     } catch (error) {
//       // Ignore token error for NEW_CARD as it's optional
//       console.log("Invalid token for NEW_CARD payment, continuing as guest");
//     }
//   }
//   try{
//   const hourlyCharterBook = await createHourlyCharterBook(req.body);
//   return res.status(201).json(hourlyCharterBook);
//   } catch(error){
//     return res.status(400).json({
//       error: error.message
//     })
//   }
// }

// async function updateHourlyCharterBookController(req, res, _next) {
//   const hourlyCharterBookId = req.params.hourlyCharterBookId;
//   const updatedHourlyCharterBookData = req.body;

//   const updatedHourlyCharterBook = await updateHourlyCharterBook(
//     hourlyCharterBookId,
//     updatedHourlyCharterBookData
//   );

//   return res.json(updatedHourlyCharterBook);
// }

// async function getAllHourlyCharterBooksController(req, res, _next) {
//   let { page, pageSize, paymentStatus, bookingStatus, sortDirection } =
//     req.query;

//   // Default sortDirection to DESC if not provided or invalid
//   sortDirection = sortDirection.toLowerCase() === "asc" ? "ASC" : "DESC";

//   const airportBooks = await getHourlyCharterBooks({
//     page,
//     pageSize,
//     paymentStatus,
//     bookingStatus,
//     sortDirection,
//   });
//   return res.status(200).json(airportBooks);
// }

// async function getHourlyCharterBookController(req, res, _next) {
//   const hourlyCharterBook = await getHourlyCharterBookById(
//     req.params.hourlyCharterBookId
//   );
//   return res.json(hourlyCharterBook);
// }

// async function deleteHourlyCharterBookController(req, res, _next) {
//   await deleteHourlyCharterBook(req.params.hourlyCharterBookId);
//   const response = successResponse("Hourly Charter book deleted successfully");
//   return res.json(response);
// }

// async function updatePaymentStatusController(req, res, _next) {
//   const hourlyCharterBookId = req.params.hourlyCharterBookId;
//   const { status } = req.body;
//   const updatedAirportBook = await updatePaymentStatus(
//     hourlyCharterBookId,
//     status
//   );
//   return res.json(updatedAirportBook);
// }

// async function updateBookingStatusController(req, res, _next) {
//   const hourlyCharterBookId = req.params.hourlyCharterBookId;
//   const { status } = req.body;
//   const updatedAirportBook = await updateBookingStatus(
//     hourlyCharterBookId,
//     status
//   );
//   return res.json(updatedAirportBook);
// }

// module.exports = {
//   createHourlyCharterBookController,
//   updateHourlyCharterBookController,
//   getAllHourlyCharterBooksController,
//   getHourlyCharterBookController,
//   deleteHourlyCharterBookController,
//   updatePaymentStatusController,
//   updateBookingStatusController,
// };




const {
  createHourlyCharterBook,
  updateHourlyCharterBook,
  updateHourlyCharterBookForUser,
  getHourlyCharterBooks,
  getHourlyCharterBookById,
  deleteHourlyCharterBook,
  updateBookingStatus,
  updatePaymentStatus,
  applyDiscountToHourlyCharterBook,
  startHourlyTrip,
  endHourlyTrip,
  extendWithLiveMeter,
  getLiveTripStatus,
  getActiveLiveTrips,
  getActiveDriverTrips,
  getDriverTripHistory,
} = require("../services/hourlyCharter/hourlyCharterBookService.js");

const authenticateToken = require("../utils/getUserFromToken.js");

const { successResponse } = require("../utils/responseUtil.js");

async function createHourlyCharterBookController(req, res, next) {
  const tokenHeader = req.header("Authorization");
  const { paymentMethod, isGuestBooking } = req.body;

  // Check if payment method requires authentication
  if ((paymentMethod === 'PRIMARY_CARD' || paymentMethod === 'EXISTING_CARD')) {
    if (!tokenHeader) {
      return res.status(401).json({ 
        error: "Authentication required for using saved payment methods" 
      });
    }

    try {
      const user = await authenticateToken(tokenHeader);
      req.body.userId = user.userId;
    } catch (error) {
      return res.status(401).json({ 
        error: "Invalid authentication token" 
      });
    }
  } else if (!isGuestBooking && tokenHeader) {
    // If user is logged in but using NEW_CARD, still attach userId
    try {
      const user = await authenticateToken(tokenHeader);
      req.body.userId = user.userId;
    } catch (error) {
      // Ignore token error for NEW_CARD as it's optional
      console.log("Invalid token for NEW_CARD payment, continuing as guest");
    }
  }
  try {
    const hourlyCharterBook = await createHourlyCharterBook(req.body);
    return res.status(201).json(hourlyCharterBook);
  } catch (error) {
    return next(error);
  }
}

async function updateHourlyCharterBookController(req, res, _next) {
  const hourlyCharterBookId = req.params.hourlyCharterBookId;
  const updatedHourlyCharterBookData = req.body;

  const isAdmin = req.user && req.user.role === "admin";
  const updatedHourlyCharterBook = await updateHourlyCharterBookForUser(
    hourlyCharterBookId,
    req.user?.userId,
    updatedHourlyCharterBookData,
    { isAdmin }
  );

  return res.json(updatedHourlyCharterBook);
}

async function getAllHourlyCharterBooksController(req, res, _next) {
  let { page, pageSize, paymentStatus, bookingStatus, sortDirection } =
    req.query;

  // Default sortDirection to DESC if not provided or invalid
  sortDirection = (sortDirection || "").toLowerCase() === "asc" ? "ASC" : "DESC";

  const airportBooks = await getHourlyCharterBooks({
    page,
    pageSize,
    paymentStatus,
    bookingStatus,
    sortDirection,
  });
  return res.status(200).json(airportBooks);
}

async function getHourlyCharterBookController(req, res, _next) {
  const hourlyCharterBook = await getHourlyCharterBookById(
    req.params.hourlyCharterBookId
  );
  return res.json(hourlyCharterBook);
}

async function deleteHourlyCharterBookController(req, res, _next) {
  await deleteHourlyCharterBook(req.params.hourlyCharterBookId);
  const response = successResponse("Hourly Charter book deleted successfully");
  return res.json(response);
}

async function updatePaymentStatusController(req, res, _next) {
  const hourlyCharterBookId = req.params.hourlyCharterBookId;
  const { status } = req.body;
  const updatedAirportBook = await updatePaymentStatus(
    hourlyCharterBookId,
    status
  );
  return res.json(updatedAirportBook);
}

async function updateBookingStatusController(req, res, _next) {
  const hourlyCharterBookId = req.params.hourlyCharterBookId;
  const { status, discountAmount } = req.body;

  const updatedHourlyCharterBook = await updateBookingStatus(hourlyCharterBookId, { bookingStatus: status, discountAmount: discountAmount });
  return res.json(updatedHourlyCharterBook);
}

async function applyDiscountToHourlyCharterBookController(req, res, next) {
  const hourlyCharterBookId = req.params.hourlyCharterBookId;
  const { discountAmount } = req.body;

  try {
    const updatedHourlyCharterBook = await applyDiscountToHourlyCharterBook(hourlyCharterBookId, discountAmount);
    return res.status(200).json(updatedHourlyCharterBook);
  } catch (error) {
    return next(error);
  }
}

// ─── LIVE billing mode controllers ──────────────────────────────────────────

async function startTripController(req, res, next) {
  const { hourlyCharterBookId } = req.params;
  const { convertToLive = false } = req.body || {};
  try {
    const booking = await startHourlyTrip(
      hourlyCharterBookId,
      { convertToLive: Boolean(convertToLive) },
      req.user.userId
    );
    return res.json(booking);
  } catch (error) {
    return next(error);
  }
}

async function extendLiveTripController(req, res, next) {
  const { hourlyCharterBookId } = req.params;
  try {
    const booking = await extendWithLiveMeter(hourlyCharterBookId);
    return res.json(booking);
  } catch (error) {
    return next(error);
  }
}

async function endTripController(req, res, next) {
  const { hourlyCharterBookId } = req.params;
  try {
    const booking = await endHourlyTrip(hourlyCharterBookId);
    return res.json(booking);
  } catch (error) {
    return next(error);
  }
}

async function getLiveStatusController(req, res, next) {
  const { hourlyCharterBookId } = req.params;
  try {
    const booking = await getHourlyCharterBookById(hourlyCharterBookId);
    const status = getLiveTripStatus(booking);
    return res.json(status);
  } catch (error) {
    return next(error);
  }
}

async function getActiveLiveTripsController(req, res) {
  const trips = await getActiveLiveTrips();
  return res.json(trips);
}

async function getActiveDriverTripsController(req, res, next) {
  try {
    const trips = await getActiveDriverTrips();
    return res.json(trips);
  } catch (error) {
    return next(error);
  }
}

async function getDriverTripHistoryController(req, res, next) {
  try {
    const { page, pageSize } = req.query;
    const result = await getDriverTripHistory({ page, pageSize }, req.user);
    return res.json(result);
  } catch (error) {
    return next(error);
  }
}

module.exports = {
  createHourlyCharterBookController,
  updateHourlyCharterBookController,
  getAllHourlyCharterBooksController,
  getHourlyCharterBookController,
  deleteHourlyCharterBookController,
  updatePaymentStatusController,
  updateBookingStatusController,
  applyDiscountToHourlyCharterBookController,
  startTripController,
  endTripController,
  extendLiveTripController,
  getLiveStatusController,
  getActiveLiveTripsController,
  getActiveDriverTripsController,
  getDriverTripHistoryController,
};
