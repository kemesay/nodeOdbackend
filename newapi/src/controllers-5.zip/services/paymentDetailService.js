const { Op } = require("sequelize");
const { PaymentDetail } = require("../models/PaymentDetail.js");

async function addOrUpdatePaymentDetail(
  creditCardNumber,
  expirationDate,
  securityCode,
  zipCode
) {
  // Find a payment detail with the given credit card details
  const existingPaymentDetail = await PaymentDetail.findOne({
    where: {
      creditCardNumber,
      expirationDate,
      securityCode,
      zipCode,
    },
  });

  if (existingPaymentDetail) {
    // If found, update the existing record
    await existingPaymentDetail.update({
      creditCardNumber,
      expirationDate,
      securityCode,
      zipCode,
    });

    return existingPaymentDetail;
  } else {
    // If not found, create a new payment detail
    const newPaymentDetail = await PaymentDetail.create({
      creditCardNumber,
      expirationDate,
      securityCode,
      zipCode,
    });

    return newPaymentDetail;
  }
}

module.exports = addOrUpdatePaymentDetail;
