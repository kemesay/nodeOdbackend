/**
 * Applies Square-related DB columns if missing (PostgreSQL).
 * Usage: npm run db:square-columns
 */
const fs = require("fs");
const path = require("path");
const { config } = require("dotenv");

config();

const { sequelize } = require("../src/config/database.js");

async function main() {
  const sqlPath = path.join(
    __dirname,
    "../database/sql/add_square_payment_columns.sql"
  );
  const sql = fs.readFileSync(sqlPath, "utf8");
  await sequelize.authenticate();
  await sequelize.query(sql);
  console.log("Square payment columns migration applied.");
  await sequelize.close();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
